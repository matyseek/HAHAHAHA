
export enum OrderStatus {
  PENDING = 'PENDING',       // Čeká na platbu
  PAID = 'PAID',             // Zaplaceno, čeká na licenci
  PROCESSING = 'PROCESSING', // Probíhá nákup na Nody
  SENT = 'SENT',             // Hotovo, odesláno klientovi
  FAILED = 'FAILED',         // Chyba (např. Nody nemá klíč)
  CANCELLED = 'CANCELLED'
}

export interface Order {
  id: string;
  orderNumber: string; // Naše interní číslo objednávky (VS)
  customerName: string;
  email: string;
  phone: string;
  totalAmount: number;
  status: OrderStatus;
  date: string;
  items: OrderItem[];
}

export interface OrderItem {
  productName: string;
  nodyId?: string; // ID produktu v Nody (pro automatický nákup)
  price: number;
}

export interface User {
  uid: number;
  name: string;
  email: string;
  phone: string;
  orders: Order[];
  licenses: LicenseKey[];
  firstSeen: string;
}

export interface LicenseKey {
  id: string;
  code: string;
  productId: string; // Vazba na WarehouseProduct.id
  activationsUsed: number;
  activationsMax: number;
  isUsed: boolean;
  isActive: boolean;
  assignedToEmail?: string;
  orderNumber?: string;
  source: 'LOCAL' | 'NODY'; // Původ klíče
  usedDate?: string;
}

export interface WarehouseProduct {
  id: string;
  nodyId?: string;      // Klíčové pro sync s Nody
  name: string;
  ean: string;
  image?: string;
  description?: string;
  price?: number;       // Naše prodejní cena
  buyPrice?: number;    // Nákupní cena z Nody
  vat?: number;
  totalKeys: number;    // Kolik máme nakoupeno lokálně
  availableKeys: number;// Kolik je volných lokálně
  remoteStock?: number; // Kolik má Nody skladem
  autoFulfill: boolean; // Zda automaticky kupovat z Nody, když dojde lokální sklad
}

export interface Payout {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'INCOME' | 'EXPENSE' | 'PAYOUT';
}

export interface PanelUser {
  id: string;
  username: string;
  role: 'ADMIN' | 'WORKER';
  email: string;
}

export interface ActionLog {
  id: string;
  userId: string;
  username: string;
  action: string;
  timestamp: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'INFO' | 'ALERT' | 'SUCCESS';
  timestamp: string;
  isRead: boolean;
}
