import React, { useState, useRef, useEffect } from 'react';
import { 
  LayoutDashboard, 
  ShoppingCart, 
  Users as UsersIcon, 
  Package, 
  CreditCard,
  LogOut,
  Bell,
  Settings
} from 'lucide-react';
import Dashboard from './components/Dashboard';
import Orders from './components/Orders';
import Users from './components/Users';
import Warehouse from './components/Warehouse';
import Payouts from './components/Payouts';
import SettingsPage from './components/Settings';
import Login from './components/Login';
import { PanelUser, ActionLog, Order, WarehouseProduct, LicenseKey, Notification } from './types';
import { MOCK_PANEL_USERS, MOCK_LOGS, MOCK_ORDERS, MOCK_PRODUCTS, MOCK_KEYS } from './constants';

type Tab = 'DASHBOARD' | 'ORDERS' | 'USERS' | 'WAREHOUSE' | 'PAYOUTS' | 'SETTINGS';

const INITIAL_NOTIFICATIONS: Notification[] = [
  { id: '1', title: 'Sklad: Nízký stav', message: 'Office 2021 má 0 volných klíčů.', type: 'ALERT', timestamp: 'Před 5 min', isRead: false },
  { id: '2', title: 'Nová objednávka', message: 'Lukáš Dvořák vytvořil objednávku #764403-5.', type: 'INFO', timestamp: 'Před 20 min', isRead: false },
  { id: '3', title: 'Import dokončen', message: 'Naimportováno 50 klíčů pro Windows 11.', type: 'SUCCESS', timestamp: 'Před 1 h', isRead: true },
];

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<PanelUser | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('DASHBOARD');
  
  const [orders, setOrders] = useState<Order[]>(MOCK_ORDERS);
  const [products, setProducts] = useState<WarehouseProduct[]>(MOCK_PRODUCTS);
  const [keys, setKeys] = useState<LicenseKey[]>(MOCK_KEYS);
  const [logs, setLogs] = useState<ActionLog[]>(MOCK_LOGS);
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFICATIONS);
  const [showNotifications, setShowNotifications] = useState(false);
  const notificationRef = useRef<HTMLDivElement>(null);

  const unreadCount = notifications.filter(n => !n.isRead).length;

  const addLog = (action: string) => {
    if (!currentUser) return;
    const newLog: ActionLog = {
      id: Math.random().toString(36).substr(2, 9),
      userId: currentUser.id,
      username: currentUser.username,
      action,
      timestamp: new Date().toLocaleString('cs-CZ')
    };
    setLogs(prev => [newLog, ...prev]);
  };

  const handleLogin = (username: string) => {
    const user = MOCK_PANEL_USERS.find(u => u.username === username) || MOCK_PANEL_USERS[0];
    setCurrentUser(user);
    addLog(`Přihlášení uživatele ${username}`);
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (notificationRef.current && !notificationRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const navItems = [
    { id: 'DASHBOARD', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'ORDERS', label: 'Objednávky', icon: ShoppingCart },
    { id: 'USERS', label: 'Uživatelé', icon: UsersIcon },
    { id: 'WAREHOUSE', label: 'Sklad', icon: Package },
    { id: 'PAYOUTS', label: 'Finance & Tým', icon: CreditCard },
  ];

  if (!currentUser) return <Login onLogin={handleLogin} />;

  const renderContent = () => {
    switch (activeTab) {
      case 'DASHBOARD': return <Dashboard orders={orders} products={products} keys={keys} onNavigate={(tab) => setActiveTab(tab as Tab)} />;
      case 'ORDERS': return <Orders orders={orders} onLog={addLog} />;
      case 'USERS': return <Users orders={orders} keys={keys} />;
      case 'WAREHOUSE': return <Warehouse products={products} keys={keys} onLog={addLog} setKeys={setKeys} setProducts={setProducts} />;
      case 'PAYOUTS': return <Payouts isAdmin={currentUser.role === 'ADMIN'} logs={logs} />;
      case 'SETTINGS': return <SettingsPage onLog={addLog} />;
      default: return <Dashboard orders={orders} products={products} keys={keys} onNavigate={(tab) => setActiveTab(tab as Tab)} />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50">
      <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col sticky top-0 h-screen overflow-hidden border-r border-slate-800">
        <div className="p-6 flex items-center gap-3 border-b border-slate-800">
          <div className="bg-blue-600 p-2 rounded-lg shadow-lg shadow-blue-900/20">
            <Package className="text-white w-5 h-5" />
          </div>
          <div>
            <h1 className="font-bold text-white text-base leading-none">Admin Panel</h1>
            <p className="text-[10px] text-slate-500 font-bold tracking-widest mt-1.5 uppercase">ID: 764403</p>
          </div>
        </div>
        
        <nav className="flex-1 p-4 space-y-1 mt-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id as Tab)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all group ${
                activeTab === item.id 
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/10' 
                : 'hover:bg-slate-800 hover:text-white'
              }`}
            >
              <item.icon className={`w-4 h-4 ${activeTab === item.id ? 'text-white' : 'text-slate-500 group-hover:text-blue-400'}`} />
              <span className="font-semibold text-sm">{item.label}</span>
            </button>
          ))}
        </nav>

        <div className="p-4 border-t border-slate-800 space-y-4">
          <div className="px-2">
            <p className="text-[9px] text-slate-600 font-bold uppercase tracking-widest mb-2">Nastavení systému</p>
            <button 
              onClick={() => setActiveTab('SETTINGS')}
              className={`w-full flex items-center gap-3 py-2 text-sm transition-colors ${activeTab === 'SETTINGS' ? 'text-white font-bold' : 'text-slate-500 hover:text-white'}`}
            >
              <Settings className="w-4 h-4" /> Konfigurace
            </button>
          </div>
          <div className="bg-slate-800/40 p-4 rounded-xl border border-slate-700/50">
            <div className="flex items-center gap-3 mb-1">
              <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-sm shadow-emerald-500/50"></div>
              <p className="font-bold text-white text-xs truncate">{currentUser.username}</p>
            </div>
            <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider pl-5">{currentUser.role}</p>
          </div>
          <button onClick={() => setCurrentUser(null)} className="w-full flex items-center gap-2 text-slate-500 hover:text-red-400 transition-colors py-2 text-xs font-bold px-2 uppercase tracking-widest">
            <LogOut className="w-4 h-4" /> Odhlásit se
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col min-h-0 overflow-hidden">
        <header className="h-16 bg-white border-b border-slate-200 px-8 flex items-center justify-between sticky top-0 z-40 shadow-sm shadow-slate-100">
          <h2 className="text-lg font-bold text-slate-800 tracking-tight">
            {activeTab === 'SETTINGS' ? 'Konfigurace systému' : navItems.find(n => n.id === activeTab)?.label}
          </h2>
          
          <div className="flex items-center gap-6">
            <div className="relative" ref={notificationRef}>
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-xl transition-all relative"
              >
                <Bell className="w-5 h-5" />
                {unreadCount > 0 && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
                )}
              </button>

              {showNotifications && (
                <div className="absolute right-0 mt-3 w-80 bg-white rounded-xl shadow-2xl border border-slate-200 z-50 overflow-hidden animate-in fade-in slide-in-from-top-2">
                  <div className="p-4 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
                    <h4 className="text-xs font-bold text-slate-800 uppercase tracking-widest">Oznámení</h4>
                    <span className="text-[10px] text-blue-600 font-bold cursor-pointer hover:underline uppercase">Označit vše</span>
                  </div>
                  <div className="max-h-80 overflow-y-auto">
                    {notifications.length > 0 ? notifications.map(n => (
                      <div key={n.id} className="p-4 border-b border-slate-50 hover:bg-slate-50 transition-colors cursor-pointer">
                        <p className={`text-[11px] font-bold ${n.type === 'ALERT' ? 'text-red-600' : 'text-slate-800'}`}>{n.title}</p>
                        <p className="text-[11px] text-slate-500 mt-1 leading-snug">{n.message}</p>
                        <p className="text-[9px] text-slate-400 mt-2 font-bold uppercase tracking-wider">{n.timestamp}</p>
                      </div>
                    )) : (
                      <div className="p-8 text-center text-slate-400 text-xs italic font-medium">Žádná nová oznámení</div>
                    )}
                  </div>
                </div>
              )}
            </div>
            <div className="h-8 w-px bg-slate-200"></div>
            <div className="flex items-center gap-4">
              <div className="text-right hidden sm:block">
                <p className="text-xs font-bold text-slate-800 leading-none">{currentUser.username}</p>
                <p className="text-[9px] text-slate-400 font-bold tracking-widest uppercase mt-1.5">{currentUser.role}</p>
              </div>
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold text-sm shadow-md shadow-blue-100 uppercase">
                {currentUser.username[0]}
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-8 bg-slate-50/50">
          <div className="max-w-7xl mx-auto">
            {renderContent()}
          </div>
        </div>
      </main>
    </div>
  );
};

export default App;