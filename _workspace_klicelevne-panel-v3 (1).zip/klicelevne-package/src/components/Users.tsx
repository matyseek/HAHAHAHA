
import React, { useState, useMemo } from 'react';
import { User, Order, LicenseKey } from '../types';
import { Mail, Phone, ShoppingBag, Key, X, Calendar, User as UserIcon, Hash } from 'lucide-react';

interface UsersProps {
  orders: Order[];
  keys: LicenseKey[];
}

const Users: React.FC<UsersProps> = ({ orders, keys }) => {
  const usersList = useMemo(() => {
    const userMap = new Map<string, User>();
    let nextUid = 1;

    // Seřadíme objednávky od nejstarších, aby UID odpovídalo pořadí registrace
    const sortedOrders = [...orders].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    sortedOrders.forEach(order => {
      const email = order.email.toLowerCase().trim();
      if (!userMap.has(email)) {
        userMap.set(email, {
          uid: nextUid++,
          name: order.customerName,
          email: email,
          phone: order.phone,
          orders: [order],
          licenses: keys.filter(k => k.assignedToEmail?.toLowerCase() === email),
          firstSeen: order.date
        });
      } else {
        const existing = userMap.get(email)!;
        existing.orders.push(order);
        // Aktualizujeme seznam licencí (mohly být přidány později)
        existing.licenses = keys.filter(k => k.assignedToEmail?.toLowerCase() === email);
      }
    });

    return Array.from(userMap.values()).reverse(); // Zobrazíme nejnovější nahoře
  }, [orders, keys]);

  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase">UID</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase">Zákazník</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase">Kontakt</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase text-center">Objednávky</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase text-right">Akce</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {usersList.map((user) => (
              <tr key={user.uid} className="hover:bg-slate-50/50 transition-colors">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-lg bg-slate-900 text-white flex items-center justify-center text-[10px] font-black">#{user.uid}</span>
                  </div>
                </td>
                <td className="px-6 py-4 font-bold text-slate-800">{user.name}</td>
                <td className="px-6 py-4">
                  <p className="text-xs text-slate-500 font-medium">{user.email}</p>
                  <p className="text-[10px] text-slate-400 font-bold">{user.phone}</p>
                </td>
                <td className="px-6 py-4 text-center">
                  <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest">{user.orders.length}x</span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button onClick={() => setSelectedUser(user)} className="text-[10px] font-black text-blue-600 hover:text-blue-800 uppercase tracking-widest">Detail</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-600 text-white flex items-center justify-center font-black text-xl shadow-lg">#{selectedUser.uid}</div>
                <div>
                  <h3 className="text-lg font-black text-slate-800">{selectedUser.name}</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Zákazník od {selectedUser.firstSeen}</p>
                </div>
              </div>
              <button onClick={() => setSelectedUser(null)}><X className="w-6 h-6 text-slate-400 hover:text-slate-600" /></button>
            </div>
            
            <div className="p-8 overflow-y-auto space-y-8 flex-1 custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">E-mail</p>
                  <p className="text-sm font-bold text-slate-700">{selectedUser.email}</p>
                </div>
                <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1">Telefon</p>
                  <p className="text-sm font-bold text-slate-700">{selectedUser.phone}</p>
                </div>
                <div className="p-4 bg-blue-600 rounded-xl shadow-lg shadow-blue-100 text-white">
                  <p className="text-[9px] font-black text-blue-100 uppercase tracking-widest mb-1">Doručené klíče</p>
                  <p className="text-2xl font-black">{selectedUser.licenses.length}</p>
                </div>
              </div>

              <div>
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2"><Key className="w-4 h-4 text-blue-600" /> Evidence doručených klíčů</h4>
                <div className="space-y-2">
                  {selectedUser.licenses.map((lic, idx) => (
                    <div key={idx} className="flex items-center justify-between p-4 border border-slate-100 rounded-xl hover:border-blue-200 transition-colors bg-white shadow-sm">
                      <div className="flex items-center gap-4">
                        <code className="text-xs font-mono font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">ID: {lic.productId}</code>
                        <span className="text-sm font-black text-slate-700">{lic.code}</span>
                      </div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{lic.usedDate?.split('T')[0] || '---'}</span>
                    </div>
                  ))}
                  {selectedUser.licenses.length === 0 && <p className="text-center py-8 text-xs font-bold text-slate-400 italic">Zatím nebyly doručeny žádné klíče.</p>}
                </div>
              </div>

              <div>
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2"><ShoppingBag className="w-4 h-4 text-blue-600" /> Historie nákupů</h4>
                <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Objednávka</th>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest">Datum</th>
                        <th className="px-6 py-3 text-[10px] font-bold text-slate-400 uppercase tracking-widest text-right">Částka</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedUser.orders.map(order => (
                        <tr key={order.id} className="text-sm">
                          <td className="px-6 py-3 font-bold text-slate-700">#{order.orderNumber}</td>
                          <td className="px-6 py-3 text-slate-400">{order.date.split(' ')[0]}</td>
                          <td className="px-6 py-3 text-right font-bold text-slate-800">{order.totalAmount} Kč</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Users;
