
import React from 'react';
import { 
  TrendingUp, 
  Users as UsersIcon, 
  AlertCircle, 
  DollarSign,
  Package,
  Calendar
} from 'lucide-react';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Order, WarehouseProduct, LicenseKey, OrderStatus } from '../types';

const chartData = [
  { name: 'Po', revenue: 12000 },
  { name: 'Út', revenue: 15000 },
  { name: 'St', revenue: 8000 },
  { name: 'Čt', revenue: 22000 },
  { name: 'Pá', revenue: 19000 },
  { name: 'So', revenue: 5000 },
  { name: 'Ne', revenue: 6500 },
];

interface DashboardProps {
  orders: Order[];
  products: WarehouseProduct[];
  keys: LicenseKey[];
  onNavigate: (tab: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ orders, products, onNavigate }) => {
  // Výpočet statistik
  const today = new Date().toLocaleDateString('cs-CZ');
  const thisMonth = new Date().getMonth();

  const revenueToday = orders
    .filter(o => o.date.includes(today))
    .reduce((sum, o) => sum + o.totalAmount, 0);

  const revenueMonth = orders
    .filter(o => new Date(o.date).getMonth() === thisMonth)
    .reduce((sum, o) => sum + o.totalAmount, 0);

  const newCustomersToday = new Set(orders.filter(o => o.date.includes(today)).map(o => o.email)).size;
  const newCustomersMonth = new Set(orders.filter(o => new Date(o.date).getMonth() === thisMonth).map(o => o.email)).size;

  const missingLicenses = orders.filter(o => o.status === OrderStatus.PAID || o.status === OrderStatus.PROCESSING).length;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Příjem dnes" value={`${revenueToday.toLocaleString()} Kč`} color="blue" icon={DollarSign} change={`+${newCustomersToday} zákazníků`} isPos={true} />
        <StatCard title="Příjem měsíc" value={`${revenueMonth.toLocaleString()} Kč`} color="emerald" icon={TrendingUp} change={`Celkem ${newCustomersMonth} tento měsíc`} isPos={true} />
        <StatCard title="Nezpracováno" value={missingLicenses.toString()} color="rose" icon={AlertCircle} highlight={missingLicenses > 0} change="Chybí licence skladem" isPos={false} />
        <StatCard title="Produkty" value={products.length.toString()} color="indigo" icon={Package} change="Aktivní v katalogu" isPos={true} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-8 pb-4 border-b border-slate-50">
            <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 uppercase tracking-wide"><Calendar className="w-4 h-4 text-blue-500" /> Týdenní přehled tržeb</h3>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', fontSize: '12px' }} />
                <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Stock Status Card */}
        <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-6 border-b border-slate-50 pb-4">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2"><Package className="w-4 h-4" /> Stav skladu</h3>
          </div>
          <div className="space-y-3 flex-1 overflow-y-auto pr-1">
            {products.map(p => (
              <StockCard key={p.id} product={p.name} stock={p.availableKeys} />
            ))}
          </div>
          <div className="mt-6 pt-4 border-t border-slate-50">
            <button 
              onClick={() => onNavigate('WAREHOUSE')}
              className="w-full py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-600 uppercase tracking-widest transition-colors"
            >
              Přejít do skladu
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Fix: Define missing StatCard helper component
const StatCard: React.FC<any> = ({ title, value, color, icon: Icon, highlight, change, isPos }) => {
  const colorMap: any = {
    blue: 'bg-blue-50 text-blue-600 ring-blue-100',
    emerald: 'bg-emerald-50 text-emerald-600 ring-emerald-100',
    indigo: 'bg-indigo-50 text-indigo-600 ring-indigo-100',
    rose: 'bg-rose-50 text-rose-600 ring-rose-100'
  };
  return (
    <div className={`bg-white p-5 rounded-2xl border transition-all ${highlight ? 'border-rose-200 ring-2 ring-rose-50 shadow-md' : 'border-slate-200 shadow-sm hover:border-slate-300'}`}>
      <div className="flex justify-between items-start mb-4">
        <div className={`p-2 rounded-lg ${colorMap[color]} ring-1 shadow-sm`}><Icon className="w-5 h-5" /></div>
        <div className="text-right">
           <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{title}</p>
           {change && (
             <p className={`text-[9px] font-bold uppercase mt-0.5 ${isPos ? 'text-emerald-500' : 'text-rose-500'}`}>{change}</p>
           )}
        </div>
      </div>
      <h4 className="text-2xl font-bold text-slate-800 tracking-tight">{value}</h4>
    </div>
  );
};

// Fix: Define missing StockCard helper component
const StockCard: React.FC<{ product: string; stock: number }> = ({ product, stock }) => {
  const isOut = stock === 0;
  const isLow = stock > 0 && stock < 5;
  return (
    <div className={`p-3.5 rounded-xl border transition-colors ${isOut ? 'border-rose-100 bg-rose-50/30' : isLow ? 'border-amber-100 bg-amber-50/30' : 'border-slate-100 bg-white hover:border-slate-200'}`}>
      <div className="flex justify-between items-center gap-4">
        <p className="text-xs font-semibold text-slate-800 truncate flex-1">{product}</p>
        <div className="flex items-center gap-2 shrink-0">
          <div className={`w-1.5 h-1.5 rounded-full ${isOut ? 'bg-rose-500 shadow-sm shadow-rose-200' : isLow ? 'bg-amber-500 shadow-sm shadow-amber-200' : 'bg-emerald-500 shadow-sm shadow-emerald-200'}`}></div>
          <span className={`text-xs font-bold font-mono ${isOut ? 'text-rose-600' : isLow ? 'text-amber-600' : 'text-slate-500'}`}>{stock} ks</span>
        </div>
      </div>
    </div>
  );
};

// Fix: Add missing default export
export default Dashboard;
