
import React, { useState, useEffect } from 'react';
import { Order, OrderStatus, WarehouseProduct } from '../types';
import { Search, X, ChevronRight, ShoppingBag, AlertTriangle, CheckCircle2, Clock, Zap, History, Plus, User, Mail, Phone, Trash2, Send } from 'lucide-react';

interface OrdersProps {
  orders: Order[];
  onLog: (action: string) => void;
}

const Orders: React.FC<OrdersProps> = ({ orders: initialOrders, onLog }) => {
  const [orders, setOrders] = useState<Order[]>(initialOrders);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Create Order States
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [availableProducts, setAvailableProducts] = useState<WarehouseProduct[]>([]);
  
  // New Order Form Data
  const [newOrderCustomer, setNewOrderCustomer] = useState('');
  const [newOrderEmail, setNewOrderEmail] = useState('');
  const [newOrderPhone, setNewOrderPhone] = useState('');
  const [newOrderItems, setNewOrderItems] = useState<{product: WarehouseProduct, qty: number}[]>([]);
  const [selectedProductToAdd, setSelectedProductToAdd] = useState('');

  // Načíst produkty pro výběr v nové objednávce
  useEffect(() => {
      fetch('/api/products')
        .then(res => res.json())
        .then(data => setAvailableProducts(Array.isArray(data) ? data : []))
        .catch(console.error);
  }, [isCreateModalOpen]);

  // Sync orders prop change
  useEffect(() => {
    setOrders(initialOrders);
  }, [initialOrders]);

  const handleProcessQueue = async () => {
    setIsProcessing(true);
    try {
        const res = await fetch('/api/cron');
        const data = await res.json();
        if (data.success) {
            alert(`Zpracováno. Odesláno ${data.emailsSent} e-mailů.`);
            onLog(`Ruční spuštění fulfillmentu: ${data.emailsSent} odesláno.`);
            // Reload page or re-fetch orders to see changes (in real app)
        } else {
            alert('Chyba při zpracování.');
        }
    } catch (e) {
        alert('Chyba spojení.');
    }
    setIsProcessing(false);
  };

  const getStatusBadge = (status: OrderStatus) => {
    const badges = {
        [OrderStatus.SENT]: <span className="flex items-center gap-1 text-emerald-600 bg-emerald-50 px-2 py-1 rounded text-[10px] font-bold uppercase"><CheckCircle2 className="w-3 h-3"/> Odesláno</span>,
        [OrderStatus.PAID]: <span className="flex items-center gap-1 text-blue-600 bg-blue-50 px-2 py-1 rounded text-[10px] font-bold uppercase"><Clock className="w-3 h-3"/> Čeká na licenci</span>,
        [OrderStatus.PROCESSING]: <span className="flex items-center gap-1 text-purple-600 bg-purple-50 px-2 py-1 rounded text-[10px] font-bold uppercase"><Zap className="w-3 h-3 animate-pulse"/> Nákup u Nody</span>,
        [OrderStatus.FAILED]: <span className="flex items-center gap-1 text-red-600 bg-red-50 px-2 py-1 rounded text-[10px] font-bold uppercase"><AlertTriangle className="w-3 h-3"/> Chyba</span>,
    };
    return badges[status] || <span className="text-slate-400">Neznámý</span>;
  };

  const getClientHistory = (email: string) => {
    return orders.filter(o => o.email === email).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const handleAddItem = () => {
      const product = availableProducts.find(p => p.id === selectedProductToAdd);
      if (product) {
          setNewOrderItems(prev => [...prev, { product, qty: 1 }]);
          setSelectedProductToAdd('');
      }
  };

  const handleRemoveItem = (index: number) => {
      setNewOrderItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmitOrder = async () => {
      if (!newOrderEmail || newOrderItems.length === 0) return alert('Vyplňte email a přidejte alespoň jednu položku.');

      const totalAmount = newOrderItems.reduce((sum, item) => sum + (item.product.price || 0), 0);
      
      const newOrder: Order = {
          id: Math.random().toString(36).substr(2, 9),
          orderNumber: `MAN-${Date.now().toString().substr(-6)}`,
          customerName: newOrderCustomer || 'Host',
          email: newOrderEmail,
          phone: newOrderPhone,
          totalAmount: totalAmount,
          status: OrderStatus.PAID, // Automaticky označíme jako zaplacené pro okamžité zpracování
          date: new Date().toLocaleString('cs-CZ'),
          items: newOrderItems.map(i => ({
              productName: i.product.name,
              price: i.product.price || 0,
              nodyId: i.product.nodyId
          }))
      };

      try {
          const res = await fetch('/api/orders', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(newOrder)
          });
          if (res.ok) {
              onLog(`Vytvořena manuální objednávka ${newOrder.orderNumber}`);
              setOrders(prev => [newOrder, ...prev]);
              setIsCreateModalOpen(false);
              // Reset form
              setNewOrderCustomer('');
              setNewOrderEmail('');
              setNewOrderItems([]);
          }
      } catch (e) {
          alert('Chyba při vytváření objednávky');
      }
  };

  return (
    <div className="space-y-4">
       {/* Actions Bar */}
       <div className="bg-white p-4 rounded-xl border border-slate-200 flex flex-col md:flex-row gap-4 justify-between items-center">
          <div className="relative flex-1 w-full">
             <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"/>
             <input 
                type="text" 
                placeholder="Hledat objednávku, email, jméno..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:border-blue-500 transition-colors"
             />
          </div>
          <div className="flex gap-2 w-full md:w-auto">
            <button 
                onClick={handleProcessQueue}
                disabled={isProcessing}
                className="flex items-center gap-2 bg-slate-100 text-slate-700 px-4 py-2.5 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-slate-200 transition-colors active:scale-95 disabled:opacity-50"
            >
                <Send className={`w-4 h-4 ${isProcessing ? 'animate-pulse' : ''}`} /> {isProcessing ? 'Odesílám...' : 'Odeslat licence'}
            </button>
            <button 
                onClick={() => setIsCreateModalOpen(true)}
                className="flex items-center gap-2 bg-blue-600 text-white px-6 py-2.5 rounded-xl font-bold text-xs uppercase tracking-widest hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/10 active:scale-95 flex-1 md:flex-none justify-center"
            >
                <Plus className="w-4 h-4" /> Nová objednávka
            </button>
          </div>
       </div>

       {/* Orders List */}
       <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
          <table className="w-full text-left">
             <thead className="bg-slate-50 border-b border-slate-200">
                <tr>
                   <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase">Číslo Obj.</th>
                   <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase">Datum</th>
                   <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase">Zákazník</th>
                   <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase text-center">Stav</th>
                   <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase text-right">Cena</th>
                   <th className="px-6 py-4"></th>
                </tr>
             </thead>
             <tbody className="divide-y divide-slate-100">
                {orders.map(order => (
                   <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-6 py-4 font-bold text-slate-800 text-sm">{order.orderNumber}</td>
                      <td className="px-6 py-4 text-xs text-slate-500 font-semibold">{order.date}</td>
                      <td className="px-6 py-4">
                         <div className="text-sm font-bold text-slate-700">{order.customerName}</div>
                         <div className="text-[10px] text-slate-400">{order.email}</div>
                      </td>
                      <td className="px-6 py-4 text-center flex justify-center">{getStatusBadge(order.status)}</td>
                      <td className="px-6 py-4 text-right font-bold text-slate-800">{order.totalAmount} Kč</td>
                      <td className="px-6 py-4 text-right">
                         <button onClick={() => setSelectedOrder(order)} className="p-2 bg-slate-100 hover:bg-blue-50 text-slate-600 hover:text-blue-600 rounded-lg transition-colors">
                            <ChevronRight className="w-4 h-4" />
                         </button>
                      </td>
                   </tr>
                ))}
             </tbody>
          </table>
       </div>

       {/* Create Order Modal */}
       {isCreateModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in zoom-in-95 duration-200">
             <div className="bg-white w-full max-w-2xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                   <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2"><ShoppingBag className="w-5 h-5 text-blue-600"/> Vytvořit manuální objednávku</h3>
                   <button onClick={() => setIsCreateModalOpen(false)}><X className="w-5 h-5 text-slate-400 hover:text-slate-600"/></button>
                </div>
                
                <div className="p-8 space-y-6 overflow-y-auto">
                    {/* Customer Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div className="relative">
                            <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"/>
                            <input type="text" placeholder="Jméno zákazníka" value={newOrderCustomer} onChange={e => setNewOrderCustomer(e.target.value)} className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold"/>
                        </div>
                        <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"/>
                            <input type="email" placeholder="Email (nutné)" value={newOrderEmail} onChange={e => setNewOrderEmail(e.target.value)} className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold"/>
                        </div>
                        <div className="relative">
                            <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400"/>
                            <input type="text" placeholder="Telefon" value={newOrderPhone} onChange={e => setNewOrderPhone(e.target.value)} className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold"/>
                        </div>
                    </div>

                    {/* Add Items */}
                    <div className="space-y-3 pt-4 border-t border-slate-100">
                        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest">Položky objednávky</h4>
                        <div className="flex gap-2">
                            <select 
                                value={selectedProductToAdd} 
                                onChange={e => setSelectedProductToAdd(e.target.value)}
                                className="flex-1 p-3 bg-white border border-slate-200 rounded-xl text-sm font-bold text-slate-700"
                            >
                                <option value="">Vyberte produkt...</option>
                                {availableProducts.map(p => (
                                    <option key={p.id} value={p.id}>{p.name} ({p.price} Kč)</option>
                                ))}
                            </select>
                            <button onClick={handleAddItem} className="bg-slate-900 text-white px-4 rounded-xl font-bold hover:bg-slate-800 transition-colors">
                                <Plus className="w-5 h-5" />
                            </button>
                        </div>

                        {/* Items List */}
                        <div className="bg-slate-50 rounded-xl border border-slate-200 overflow-hidden">
                            {newOrderItems.length === 0 ? (
                                <div className="p-4 text-center text-xs text-slate-400 italic">Zatím žádné položky</div>
                            ) : (
                                newOrderItems.map((item, idx) => (
                                    <div key={idx} className="flex justify-between items-center p-3 border-b border-slate-200 last:border-0">
                                        <div className="flex items-center gap-3">
                                            <div className="w-8 h-8 bg-white rounded border border-slate-200 flex items-center justify-center">
                                                <ShoppingBag className="w-4 h-4 text-slate-300"/>
                                            </div>
                                            <div>
                                                <p className="text-sm font-bold text-slate-700">{item.product.name}</p>
                                                <p className="text-[10px] text-slate-400 uppercase font-bold">{item.product.price} Kč</p>
                                            </div>
                                        </div>
                                        <button onClick={() => handleRemoveItem(idx)} className="text-slate-400 hover:text-red-500 transition-colors">
                                            <Trash2 className="w-4 h-4" />
                                        </button>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                    <div className="flex justify-end pt-2">
                        <div className="text-right">
                            <p className="text-xs text-slate-400 font-bold uppercase">Celkem k úhradě</p>
                            <p className="text-2xl font-black text-slate-800">
                                {newOrderItems.reduce((sum, i) => sum + (i.product.price || 0), 0)} Kč
                            </p>
                        </div>
                    </div>
                </div>

                <div className="p-6 bg-slate-50 border-t border-slate-200 flex justify-end gap-3">
                    <button onClick={() => setIsCreateModalOpen(false)} className="px-6 py-3 text-slate-500 font-bold text-xs uppercase hover:text-slate-800">Zrušit</button>
                    <button onClick={handleSubmitOrder} className="px-8 py-3 bg-blue-600 text-white rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-blue-700 shadow-lg active:scale-95 transition-all">
                        Potvrdit a Vytvořit
                    </button>
                </div>
             </div>
          </div>
       )}

       {/* Detail Modal */}
       {selectedOrder && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm animate-in fade-in duration-200">
             <div className="bg-white w-full max-w-2xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
                <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50">
                   <h3 className="text-lg font-bold text-slate-800">Detail objednávky #{selectedOrder.orderNumber}</h3>
                   <button onClick={() => setSelectedOrder(null)}><X className="w-5 h-5 text-slate-400 hover:text-slate-600"/></button>
                </div>
                
                <div className="p-8 space-y-8 overflow-y-auto custom-scrollbar">
                   {/* Info Grid */}
                   <div className="grid grid-cols-2 gap-4">
                      <div className="p-4 border border-slate-200 rounded-xl bg-slate-50/50">
                         <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Zákazník</p>
                         <p className="font-bold text-slate-800">{selectedOrder.customerName}</p>
                         <p className="text-sm text-slate-500 font-medium">{selectedOrder.email}</p>
                         <p className="text-xs text-slate-400 mt-1">{selectedOrder.phone}</p>
                      </div>
                      <div className="p-4 border border-slate-200 rounded-xl bg-slate-50/50 flex flex-col justify-between">
                         <div>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Stav objednávky</p>
                            <div className="mt-1">{getStatusBadge(selectedOrder.status)}</div>
                         </div>
                         <div className="mt-2 text-right">
                             <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Celkem</p>
                             <p className="text-xl font-black text-slate-800">{selectedOrder.totalAmount} Kč</p>
                         </div>
                      </div>
                   </div>
                   
                   {/* Items List */}
                   <div>
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                          <ShoppingBag className="w-3 h-3" /> Položky objednávky
                      </p>
                      <div className="border border-slate-200 rounded-xl overflow-hidden">
                         {selectedOrder.items.map((item, idx) => (
                            <div key={idx} className="p-4 border-b border-slate-100 last:border-0 flex justify-between items-center hover:bg-slate-50">
                               <div>
                                   <span className="font-bold text-slate-700 text-sm block">{item.productName}</span>
                                   {item.nodyId && <span className="text-[9px] text-blue-500 font-bold bg-blue-50 px-1.5 rounded uppercase tracking-tighter">Nody ID: {item.nodyId}</span>}
                               </div>
                               <span className="text-sm font-mono font-bold text-slate-500">{item.price} Kč</span>
                            </div>
                         ))}
                      </div>
                   </div>

                   {/* Client History Section */}
                   <div className="pt-4 border-t border-slate-100">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
                          <History className="w-3 h-3" /> Historie objednávek klienta
                      </p>
                      <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                          <table className="w-full text-left">
                              <thead className="bg-slate-50 border-b border-slate-100">
                                  <tr>
                                      <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest">Objednávka</th>
                                      <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest">Datum</th>
                                      <th className="px-4 py-3 text-[9px] font-bold text-slate-400 uppercase tracking-widest text-right">Stav klíčů</th>
                                  </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                  {getClientHistory(selectedOrder.email).map((histOrder) => (
                                      <tr key={histOrder.id} className={`hover:bg-slate-50 transition-colors ${histOrder.id === selectedOrder.id ? 'bg-blue-50/60' : ''}`}>
                                          <td className="px-4 py-2.5 text-xs font-bold text-slate-700">#{histOrder.orderNumber}</td>
                                          <td className="px-4 py-2.5 text-[11px] font-medium text-slate-500">{histOrder.date}</td>
                                          <td className="px-4 py-2.5 text-right">
                                              {histOrder.status === OrderStatus.SENT ? (
                                                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                                                      <CheckCircle2 className="w-3 h-3" /> Dodáno
                                                  </span>
                                              ) : (
                                                  <span className="inline-flex items-center gap-1 text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-100">
                                                      <Clock className="w-3 h-3" /> Čeká se
                                                  </span>
                                              )}
                                          </td>
                                      </tr>
                                  ))}
                              </tbody>
                          </table>
                      </div>
                   </div>
                </div>

                <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
                   <button onClick={() => setSelectedOrder(null)} className="px-6 py-2.5 bg-slate-900 text-white text-xs font-bold rounded-xl uppercase tracking-widest hover:bg-slate-800 transition-colors shadow-lg active:scale-95">Zavřít</button>
                </div>
             </div>
          </div>
       )}
    </div>
  );
};

export default Orders;
