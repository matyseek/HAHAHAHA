
export enum OrderStatus {
  PENDING = 'PENDING',
  PAID = 'PAID',
  PROCESSING = 'PROCESSING',
  SENT = 'SENT',
  FAILED = 'FAILED',
  CANCELLED = 'CANCELLED'
}

export interface OrderItem {
  productName: string;
  nodyId?: string;
  price: number;
}

export interface Order {
  id: string;
  orderNumber: string;
  customerName: string;
  email: string;
  phone: string;
  totalAmount: number;
  status: OrderStatus;
  date: string;
  items: OrderItem[];
}

export interface LicenseKey {
  id: string;
  code: string;
  productId: string;
  activationsUsed: number;
  activationsMax: number;
  isUsed: boolean;
  isActive: boolean;
  assignedToEmail?: string;
  orderNumber?: string;
  source: 'LOCAL' | 'NODY';
  usedDate?: string;
}

export interface User {
  uid: number;
  name: string;
  email: string;
  phone: string;
  orders: Order[];
  licenses: LicenseKey[];
  firstSeen: string;
}

export interface WarehouseProduct {
  id: string;
  nodyId?: string;
  name: string;
  ean: string;
  image?: string;
  description?: string;
  price: number;
  buyPrice?: number;
  totalKeys: number;
  availableKeys: number;
  remoteStock?: number;
  autoFulfill: boolean;
}

export interface Payout {
  id: string;
  date: string;
  description: string;
  amount: number;
  type: 'INCOME' | 'EXPENSE' | 'PAYOUT';
}

export interface ActionLog {
  id: string;
  userId: string;
  username: string;
  action: string;
  timestamp: string;
}

export interface PanelUser {
  id: string;
  username: string;
  role: 'ADMIN' | 'WORKER';
  email: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'INFO' | 'ALERT' | 'SUCCESS';
  timestamp: string;
  isRead: boolean;
}
