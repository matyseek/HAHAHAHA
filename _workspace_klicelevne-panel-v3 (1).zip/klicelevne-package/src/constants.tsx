import { Order, OrderStatus, WarehouseProduct, LicenseKey, Payout, PanelUser, ActionLog } from './types';

// Remove all fake data - will be populated from real database
export const MOCK_ORDERS: Order[] = [];
export const MOCK_KEYS: LicenseKey[] = [];
export const MOCK_PRODUCTS: WarehouseProduct[] = [];
export const MOCK_PAYOUTS: Payout[] = [];
export const MOCK_PANEL_USERS: PanelUser[] = [
  { id: 'u1', username: 'admin', role: 'ADMIN', email: 'podpora@klicelevne.cz' },
];
export const MOCK_LOGS: ActionLog[] = [];