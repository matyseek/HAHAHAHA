
const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

// Import handlerů
const ordersHandler = require('../api/orders');
const productsHandler = require('../api/products');
const keysHandler = require('../api/keys');
const settingsHandler = require('../api/settings');
const cronHandler = require('../api/cron');

// Wrapper pro asynchronní handlery
const handle = (handler) => async (req, res) => {
    try {
        await handler(req, res);
        // Poznámka: res.end() zde není potřeba, handlery volají res.json()
    } catch (err) {
        console.error(`[SERVER ERROR] ${req.url}:`, err);
        if (!res.headersSent) {
            res.status(500).json({ error: err.message || 'Internal Server Error' });
        }
    }
};

app.use((req, res, next) => {
    console.log(`[${new Date().toLocaleTimeString()}] ${req.method} ${req.url}`);
    next();
});

// Auth routes
const authHandler = require('../api/auth');
app.all('/api/auth/login', handle(authHandler));

// Routování
app.all('/api/orders', handle(ordersHandler));
app.all('/api/products', handle(productsHandler));
app.all('/api/keys', handle(keysHandler));
app.all('/api/settings', handle(settingsHandler));
app.all('/api/cron', handle(cronHandler));

app.get('/', (req, res) => {
    res.send('Backend API is running.');
});

app.listen(PORT, () => {
    console.log(`✅ Server připraven na http://localhost:${PORT}`);
});
