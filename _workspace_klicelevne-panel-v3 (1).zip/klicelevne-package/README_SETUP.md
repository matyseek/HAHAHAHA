# Nody.cz E-shop Admin Panel - Setup Guide

## 🚀 Quick Start

Your admin panel is now running and fully functional! Access it at:
**https://3000-5ec9e0ae-a999-4917-b941-f298e3b11c33.sandbox-service.public.prod.myninja.ai**

## 🔐 First Login

**Default Credentials:**
- **Username:** `admin`
- **Password:** `admin123`

⚠️ **IMPORTANT:** Change this password immediately after first login!

## ⚙️ Configuration

### 1. Nody.cz Integration

1. Navigate to **Settings → Nody Integrace**
2. Enter the following:
   - **API URL:** `https://api.nody.cz/v1`
   - **API Key:** `UmhgmjllI6hhROY3R6hoBlPk0RVz8MLY6aF5MQ`
3. **Enable Features:**
   - ✅ **Globální automatický nákup** - Automatically buy licenses from Nody when stock is low
   - Set **Upozornit při kreditu pod** to your desired threshold (default: 1000 Kč)
4. Click **Uložit změny**

### 2. Email Configuration (SMTP)

For sending automated license emails:

**For Outlook/Office 365 Custom Domain:**
- **SMTP Host:** `smtp.office365.com`
- **Port:** 587
- **User:** Your email address (e.g., `info@vasdomena.cz`)
- **Pass:** Your email password or app-specific password

**For Gmail:**
- **SMTP Host:** `smtp.gmail.com`
- **Port:** 587
- **User:** Your Gmail address
- **Pass:** App-specific password (enable 2FA first)

**For other providers:**
Use your provider's SMTP settings in the **Settings → SMTP & E-mail** section.

## 📦 Managing Products

### Sync Products from Nody.cz
1. Go to **Sklad** (Warehouse) tab
2. Click the **Sync z Nody** button
3. Products will be automatically imported with:
   - Product names and descriptions
   - Images
   - EAN codes
   - Prices and VAT
   - Remote stock levels

### Add License Keys
**Manual Method:**
1. Go to **Sklad**
2. Click on a product
3. Add license keys manually
4. Keys will be marked as available for orders

**Automatic Method:**
1. Enable **Globální automatický nákup** in Settings
2. System automatically purchases from Nody when:
   - Order comes in with no available keys
   - Stock drops below threshold

## 📋 Order Processing

### Manual Processing
1. Go to **Objednávky** (Orders) tab
2. Filter orders by status (Paid/Pending)
3. Select orders to process
4. Click **Odeslat licence** button
5. System will:
   - Assign available license keys
   - Send professional HTML emails to customers
   - Update order status to "SENT"

### Automatic Processing
1. Enable auto-fulfillment in Settings
2. System automatically processes paid orders:
   - Finds or purchases license keys
   - Sends emails immediately
   - Updates order status
   - Logs all actions

## 📊 Dashboard Features

Your admin panel includes:

- **Dashboard:** Overview of orders, stock, and revenue
- **Orders:** Full order management with status tracking
- **Users:** Customer management and order history
- **Warehouse:** Product and license key management
- **Finance:** Payouts and transaction tracking
- **Settings:** Complete system configuration

## 📧 Email Templates

The system sends professional HTML emails including:

### License Delivery Email
- Store branding with your name
- Order information
- Clear license key display
- Step-by-step activation instructions
- Important usage notes
- Professional footer

### Admin Notifications
- Low stock alerts
- System errors
- Order processing failures

## 🔔 Notifications

The bell icon (🔔) shows system notifications:
- Low stock warnings
- Failed email sends
- Order processing issues
- System errors

Click **"Označit vše"** to mark all as read.

## 🛠️ Advanced Features

### Cron Jobs (Automated Tasks)
The system supports automated tasks:
- **Low Stock Check:** Monitors stock levels and sends alerts
- **Auto Fulfill Orders:** Processes pending orders automatically
- **Sync Nody Catalog:** Keeps product catalog updated

These can be triggered manually or set up as scheduled tasks.

### API Endpoints
The system provides REST API endpoints:
- `POST /api/auth/login` - Authentication
- `GET/POST /api/orders` - Order management
- `GET/POST /api/products` - Product management
- `GET/POST /api/keys` - License key management
- `GET/POST /api/settings` - Settings management
- `POST /api/cron` - Trigger automated tasks

## 📝 Database

The system uses a JSON file database (`database.json`) that stores:
- Users and authentication data
- Orders and order items
- Products and inventory
- License keys and assignments
- Settings and configuration
- Activity logs

## 🎨 UI Features

- Modern, clean interface with blue color scheme
- Responsive design for all screen sizes
- Real-time updates and notifications
- Professional admin panel layout
- Czech language interface
- Smooth animations and transitions

## 🚨 Troubleshooting

### Login Issues
- Verify username and password
- Check database file exists
- Ensure server is running on port 3001

### Email Not Sending
- Verify SMTP settings are correct
- Check email/password are correct
- For Gmail, use app-specific password
- Check firewall/port settings

### Nody Integration Issues
- Verify API key is correct
- Check API URL is accurate
- Ensure you have internet connection
- Contact Nody support if API is down

### Orders Not Processing
- Check if licenses are available
- Verify auto-purchase is enabled
- Check Nody API is configured
- Review error logs in console

## 📞 Support

For issues or questions:
1. Check the console logs for error messages
2. Review the database.json file
3. Verify all settings are correct
4. Contact your system administrator

## 🎉 You're All Set!

Your Nody.cz e-shop admin panel is now fully configured and ready to use. The system will:
- Automatically manage license keys
- Send professional emails to customers
- Sync products from Nody.cz
- Process orders efficiently
- Monitor stock levels
- Send you notifications when needed

Happy selling! 🚀