
import React from 'react';
import { 
  TrendingUp, 
  Users as UsersIcon, 
  AlertCircle, 
  DollarSign,
  Package,
  Calendar,
  Clock
} from 'lucide-react';
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Order, WarehouseProduct, LicenseKey, OrderStatus } from '../types';

const chartData = [
  { name: 'Po', revenue: 12000 },
  { name: 'Út', revenue: 15000 },
  { name: 'St', revenue: 8000 },
  { name: 'Čt', revenue: 22000 },
  { name: 'Pá', revenue: 19000 },
  { name: 'So', revenue: 5000 },
  { name: 'Ne', revenue: 6500 },
];

interface DashboardProps {
  orders: Order[];
  products: WarehouseProduct[];
  keys: LicenseKey[];
  onNavigate: (tab: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ orders, products, onNavigate }) => {
  const unfinishedOrders = orders.filter(o => o.status === OrderStatus.PAID || o.status === OrderStatus.PROCESSING).length;

  return (
    <div className="space-y-6">
      {/* Quick Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Dnešní tržba" value="15 420 Kč" color="blue" icon={DollarSign} change="+12.5%" isPos={true} />
        <StatCard title="Měsíční tržba" value="342 800 Kč" color="emerald" icon={TrendingUp} change="+5.2%" isPos={true} />
        <StatCard title="Noví klienti" value="24" color="indigo" icon={UsersIcon} change="+8 dnes" isPos={true} />
        <StatCard title="Nedodělky" value={unfinishedOrders.toString()} color="rose" icon={AlertCircle} highlight={unfinishedOrders > 0} change="Action required" isPos={false} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Revenue Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-8 border-b border-slate-50 pb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-800 flex items-center gap-2 uppercase tracking-wide"><Calendar className="w-4 h-4 text-blue-500" /> Týdenní vývoj tržeb</h3>
              <p className="text-[10px] text-slate-400 font-semibold mt-1 uppercase tracking-widest">Srovnání s předchozím týdnem</p>
            </div>
            <div className="flex gap-2">
              <span className="flex items-center gap-1.5 px-3 py-1 bg-slate-50 border border-slate-200 rounded-lg text-[9px] font-bold text-slate-500 uppercase tracking-widest cursor-pointer hover:bg-slate-100 transition-colors">
                Detailní report
              </span>
            </div>
          </div>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 11}} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)', fontSize: '12px' }} />
                <Area type="monotone" dataKey="revenue" stroke="#3b82f6" strokeWidth={3} fillOpacity={1} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Stock Status Card */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col">
          <div className="flex justify-between items-center mb-6 border-b border-slate-50 pb-4">
            <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2"><Package className="w-4 h-4" /> Stav skladu</h3>
            <span className="text-[9px] font-bold text-slate-300 uppercase">Live monitoring</span>
          </div>
          <div className="space-y-3 flex-1 overflow-y-auto pr-1 custom-scrollbar">
            {products.map(p => (
              <StockCard key={p.id} product={p.name} stock={p.availableKeys} />
            ))}
          </div>
          <div className="mt-6 pt-4 border-t border-slate-50">
            <button 
              onClick={() => onNavigate('WAREHOUSE')}
              className="w-full py-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg text-[10px] font-bold text-slate-600 uppercase tracking-widest transition-colors"
            >
              Přejít do skladu
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Fix: Use React.FC to properly handle component props and avoid 'key' prop errors
const StatCard: React.FC<any> = ({ title, value, color, icon: Icon, highlight, change, isPos }) => {
  const colorMap: any = {
    blue: 'bg-blue-50 text-blue-600 ring-blue-100',
    emerald: 'bg-emerald-50 text-emerald-600 ring-emerald-100',
    indigo: 'bg-indigo-50 text-indigo-600 ring-indigo-100',
    rose: 'bg-rose-50 text-rose-600 ring-rose-100'
  };
  return (
    <div className={`bg-white p-5 rounded-xl border transition-all ${highlight ? 'border-rose-200 ring-2 ring-rose-50 shadow-md' : 'border-slate-200 shadow-sm hover:border-slate-300'}`}>
      <div className="flex justify-between items-start mb-4">
        <div className={`p-2 rounded-lg ${colorMap[color]} ring-1 shadow-sm`}><Icon className="w-5 h-5" /></div>
        <div className="text-right">
           <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{title}</p>
           {change && (
             <p className={`text-[9px] font-bold uppercase mt-0.5 ${isPos ? 'text-emerald-500' : 'text-rose-500'}`}>{change}</p>
           )}
        </div>
      </div>
      <h4 className="text-2xl font-bold text-slate-800 tracking-tight">{value}</h4>
    </div>
  );
};

// Fix: Use React.FC to properly handle component props and avoid 'key' prop errors
const StockCard: React.FC<{ product: string; stock: number }> = ({ product, stock }) => {
  const isOut = stock === 0;
  const isLow = stock > 0 && stock < 5;
  return (
    <div className={`p-3.5 rounded-xl border transition-colors ${isOut ? 'border-rose-100 bg-rose-50/30' : isLow ? 'border-amber-100 bg-amber-50/30' : 'border-slate-100 bg-white hover:border-slate-200'}`}>
      <div className="flex justify-between items-center gap-4">
        <p className="text-xs font-semibold text-slate-800 truncate flex-1">{product}</p>
        <div className="flex items-center gap-2 shrink-0">
          <div className={`w-1.5 h-1.5 rounded-full ${isOut ? 'bg-rose-500 shadow-sm shadow-rose-200' : isLow ? 'bg-amber-500 shadow-sm shadow-amber-200' : 'bg-emerald-500 shadow-sm shadow-emerald-200'}`}></div>
          <span className={`text-xs font-bold font-mono ${isOut ? 'text-rose-600' : isLow ? 'text-amber-600' : 'text-slate-500'}`}>{stock} ks</span>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
