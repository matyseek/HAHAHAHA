import React, { useState } from 'react';
import { User, Order, LicenseKey, OrderStatus } from '../types';
import { Mail, Phone, ShoppingBag, Key, X, ExternalLink, User as UserIcon, Calendar, Clock } from 'lucide-react';

interface UsersProps {
  orders: Order[];
  keys: LicenseKey[];
}

const Users: React.FC<UsersProps> = ({ orders, keys }) => {
  const users: User[] = React.useMemo(() => {
    const userMap = new Map<string, User>();
    let nextUid = 1;

    orders.forEach(order => {
      if (!userMap.has(order.email)) {
        userMap.set(order.email, {
          uid: nextUid++,
          name: order.customerName,
          email: order.email,
          phone: order.phone,
          orders: [order],
          licenses: keys.filter(k => k.assignedToEmail === order.email),
          firstSeen: order.date.split(' ')[0]
        });
      } else {
        const user = userMap.get(order.email)!;
        user.orders.push(order);
      }
    });

    return Array.from(userMap.values());
  }, [orders, keys]);

  const [selectedUser, setSelectedUser] = useState<User | null>(null);

  const getUnpaidCount = (user: User) => {
    return user.orders.filter(o => o.status === OrderStatus.PENDING).length;
  };

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">UID</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">Zákazník</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider">E-mail</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider text-center">Historie</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-wider text-right">Profil</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {users.map((user) => (
              <tr key={user.uid} className="hover:bg-slate-50/30 transition-colors">
                <td className="px-6 py-4">
                  <span className="font-bold text-blue-600 text-sm">#{user.uid}</span>
                </td>
                <td className="px-6 py-4 font-semibold text-slate-800 text-sm">{user.name}</td>
                <td className="px-6 py-4 text-sm text-slate-500 font-medium">{user.email}</td>
                <td className="px-6 py-4 text-center">
                  <span className="px-3 py-1 bg-slate-100 text-slate-600 rounded-lg text-[10px] font-bold uppercase ring-1 ring-slate-200/50">
                    {user.orders.length} objednávek
                  </span>
                </td>
                <td className="px-6 py-4 text-right">
                  <button 
                    onClick={() => setSelectedUser(user)}
                    className="text-xs font-bold text-blue-600 hover:text-blue-800 hover:underline px-2 py-1 transition-all"
                  >
                    PROHLÉDNOUT
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {selectedUser && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-6 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-4xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-8 py-6 border-b border-slate-200 flex justify-between items-center bg-slate-50">
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 rounded-xl bg-blue-600 flex items-center justify-center text-white text-2xl font-bold shadow-lg shadow-blue-100">
                  {selectedUser.name[0]}
                </div>
                <div>
                  <h3 className="text-xl font-bold text-slate-900 leading-none">{selectedUser.name}</h3>
                  <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest mt-2">UID: #{selectedUser.uid} • První aktivita: {selectedUser.firstSeen}</p>
                </div>
              </div>
              <button onClick={() => setSelectedUser(null)} className="p-2.5 hover:bg-slate-200 rounded-xl transition-colors"><X className="w-7 h-7 text-slate-400" /></button>
            </div>
            
            <div className="p-10 overflow-y-auto space-y-10 flex-1 custom-scrollbar">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                 <div className="space-y-4">
                    <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Mail className="w-4 h-4" /> Kontaktní údaje</h4>
                    <div className="space-y-2">
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex items-center justify-between">
                        <span className="text-xs text-slate-400 font-bold uppercase tracking-tighter">E-mail:</span>
                        <span className="text-sm font-bold text-slate-800">{selectedUser.email}</span>
                      </div>
                      <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex items-center justify-between">
                        <span className="text-xs text-slate-400 font-bold uppercase tracking-tighter">Telefon:</span>
                        <span className="text-sm font-bold text-slate-800">{selectedUser.phone}</span>
                      </div>
                    </div>
                 </div>
                 <div className="space-y-4">
                    <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2"><Clock className="w-4 h-4" /> Statistiky klienta</h4>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="bg-slate-900 p-5 rounded-xl text-white text-center shadow-lg shadow-slate-200">
                        <p className="text-2xl font-bold">{selectedUser.orders.length}</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-1">Nákupy</p>
                      </div>
                      <div className="bg-blue-600 p-5 rounded-xl text-white text-center shadow-lg shadow-blue-100">
                        <p className="text-2xl font-bold">{selectedUser.licenses.length}</p>
                        <p className="text-[10px] font-bold text-blue-200 uppercase tracking-widest mt-1">Licence</p>
                      </div>
                    </div>
                 </div>
              </div>

              <div className="space-y-5">
                 <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                    <Key className="w-4 h-4 text-blue-500" /> Historie vydaných klíčů
                 </h4>
                 <div className="grid grid-cols-1 gap-3">
                    {selectedUser.licenses.map((lic, idx) => (
                      <div key={idx} className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-xl shadow-sm">
                        <div className="flex items-center gap-5">
                          <code className="text-sm font-mono font-bold text-blue-600 bg-blue-50 px-3 py-1 rounded-lg border border-blue-100/50">{lic.code}</code>
                          <div>
                            <p className="text-[11px] font-bold text-slate-700 uppercase">Produkt ID: {lic.productId}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 text-slate-400 text-[10px] font-bold uppercase tracking-widest">
                          <Calendar className="w-4 h-4" /> {lic.usedDate || 'Neznámé datum'}
                        </div>
                      </div>
                    ))}
                    {selectedUser.licenses.length === 0 && (
                       <div className="p-10 border-2 border-dashed border-slate-100 rounded-xl text-center">
                          <p className="text-sm italic text-slate-400 font-semibold uppercase tracking-widest">Žádná historie licencí.</p>
                       </div>
                    )}
                 </div>
              </div>

              <div className="space-y-5">
                <h4 className="text-[11px] font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                   <ShoppingBag className="w-4 h-4 text-blue-500" /> Evidence objednávek
                </h4>
                <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase">Objednávka</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase">Datum</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase text-right">Hodnota</th>
                        <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase text-center">Stav</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 bg-white">
                      {selectedUser.orders.map((order) => (
                        <tr key={order.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-6 py-4 font-bold text-slate-700 text-sm">{order.orderNumber}</td>
                          <td className="px-6 py-4 text-slate-500 text-xs font-semibold">{order.date.split(' ')[0]}</td>
                          <td className="px-6 py-4 font-bold text-slate-800 text-sm text-right">{order.totalAmount.toLocaleString()} Kč</td>
                          <td className="px-6 py-4 text-center">
                            <span className={`text-[9px] font-bold px-2.5 py-1 rounded-lg uppercase tracking-widest ring-1 ring-inset ${
                              order.status === 'SENT' ? 'bg-emerald-50 text-emerald-600 ring-emerald-100' : 'bg-slate-100 text-slate-500 ring-slate-200'
                            }`}>{order.status}</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="px-10 py-6 border-t border-slate-200 bg-slate-50 flex justify-end gap-4">
               <button className="flex items-center gap-2 text-xs font-bold text-slate-400 hover:text-blue-600 transition-colors uppercase tracking-widest">
                <ExternalLink className="w-4 h-4" /> Otevřít kartu klienta
              </button>
              <button 
                onClick={() => setSelectedUser(null)} 
                className="px-8 py-3 bg-slate-900 text-white rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-slate-800 transition-colors"
              >
                Zavřít profil
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Users;