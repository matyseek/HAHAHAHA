import React, { useState } from 'react';
import { Package, Lock, User, AlertCircle } from 'lucide-react';

interface LoginProps {
  onLogin: (username: string) => void;
}

const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      // Real authentication through backend
      const apiUrl = import.meta.env.VITE_API_URL || 'http://localhost:3001';
      console.log('[LOGIN] Using API URL:', apiUrl);
      
      const response = await fetch(`${apiUrl}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ username, password }),
      });

      console.log('[LOGIN] Response status:', response.status);
      console.log('[LOGIN] Response ok:', response.ok);

      if (!response.ok) {
        const text = await response.text();
        console.error('[LOGIN] Error response:', text);
        try {
          const data = JSON.parse(text);
          throw new Error(data.error || 'Přihlášení selhalo');
        } catch {
          throw new Error('Přihlášení selhalo');
        }
      }

      const text = await response.text();
      console.log('[LOGIN] Response text:', text);
      
      if (!text.trim()) {
        throw new Error('Prázdná odpověď od serveru');
      }

      const data = JSON.parse(text);
      console.log('[LOGIN] Success:', data);
      
      onLogin(data.user.username);
    } catch (err: any) {
      console.error('[LOGIN] Error:', err);
      setError(err.message || 'Došlo k chybě při přihlášení');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-100 flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-3xl shadow-2xl overflow-hidden border border-slate-200">
        <div className="bg-blue-600 p-8 text-center text-white">
          <div className="bg-white/20 p-4 rounded-2xl w-fit mx-auto mb-4 backdrop-blur-md">
            <Package className="w-10 h-10" />
          </div>
          <h1 className="text-2xl font-black tracking-tight">Shoptet Admin</h1>
          <p className="text-blue-100 text-sm mt-1">Vítejte zpět v panelu pro správu licencí</p>
        </div>
        
        <form onSubmit={handleSubmit} className="p-8 space-y-6">
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
              <p className="text-sm text-red-700 font-medium">{error}</p>
            </div>
          )}

          <div>
            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Uživatelské jméno</label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-semibold text-slate-700 transition-all"
                placeholder="Např. admin"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-black text-slate-400 uppercase tracking-widest mb-2">Heslo</label>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 w-5 h-5" />
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-12 pr-4 py-4 bg-slate-50 border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 font-semibold text-slate-700 transition-all"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          <button 
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black shadow-lg shadow-blue-100 transition-all transform active:scale-[0.98] disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Přihlašuji...' : 'Přihlásit se'}
          </button>
          
          <p className="text-center text-xs text-slate-400 font-medium">
            Problémy s přihlášením? Kontaktujte administrátora.
          </p>
        </form>
      </div>
    </div>
  );
};

export default Login;