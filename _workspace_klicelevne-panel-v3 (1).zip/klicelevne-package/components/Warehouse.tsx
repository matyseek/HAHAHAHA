
import React, { useState, useEffect } from 'react';
import { WarehouseProduct, LicenseKey } from '../types';
import { 
  Plus, 
  Trash2, 
  Pencil,
  X, 
  Save,
  Check,
  AlertCircle,
  Hash,
  Package,
  Barcode,
  Image as ImageIcon,
  FileText,
  DollarSign,
  CloudDownload,
  Database,
  Zap,
  MoreHorizontal
} from 'lucide-react';

interface WarehouseProps {
  products: WarehouseProduct[];
  keys: LicenseKey[];
  onLog: (action: string) => void;
  setKeys: React.Dispatch<React.SetStateAction<LicenseKey[]>>;
  setProducts: React.Dispatch<React.SetStateAction<WarehouseProduct[]>>;
}

const Warehouse: React.FC<WarehouseProps> = ({ products, keys, onLog, setKeys, setProducts }) => {
  // UI States
  const [selectedProductKeys, setSelectedProductKeys] = useState<WarehouseProduct | null>(null); // Pro správu klíčů
  const [isProductModalOpen, setIsProductModalOpen] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [editMode, setEditMode] = useState<WarehouseProduct | null>(null); // Pokud null, vytváříme nový

  // Form Data (pro Create i Edit)
  const [formData, setFormData] = useState<Partial<WarehouseProduct>>({
    name: '',
    ean: '',
    price: 0,
    description: '',
    image: '',
    autoFulfill: false
  });

  // Key Management State
  const [newKeyCode, setNewKeyCode] = useState('');
  const [newKeyActivations, setNewKeyActivations] = useState(1);

  // --- PRODUCT MANAGEMENT ---

  const openCreateModal = () => {
    setEditMode(null);
    setFormData({ name: '', ean: '', price: 0, description: '', image: '', autoFulfill: false });
    setIsProductModalOpen(true);
  };

  const openEditModal = (product: WarehouseProduct) => {
    setEditMode(product);
    setFormData({
        name: product.name,
        ean: product.ean,
        price: product.price,
        description: product.description,
        image: product.image,
        autoFulfill: product.autoFulfill
    });
    setIsProductModalOpen(true);
  };

  const handleSaveProduct = () => {
    if (!formData.name) return alert('Název je povinný');

    if (editMode) {
        // UPDATE
        setProducts(prev => prev.map(p => p.id === editMode.id ? { ...p, ...formData } as WarehouseProduct : p));
        onLog(`Aktualizace produktu: ${formData.name}`);
    } else {
        // CREATE
        const newProduct: WarehouseProduct = {
            id: `p${Date.now()}`,
            name: formData.name || 'Nový produkt',
            ean: formData.ean || '',
            image: formData.image || '',
            description: formData.description || '',
            price: Number(formData.price) || 0,
            totalKeys: 0,
            availableKeys: 0,
            autoFulfill: formData.autoFulfill || false
        };
        setProducts(prev => [...prev, newProduct]);
        onLog(`Vytvořen nový produkt: ${newProduct.name}`);
    }
    setIsProductModalOpen(false);
  };

  const handleDeleteProduct = (id: string, name: string) => {
      if (confirm(`Opravdu smazat produkt "${name}" a všechny jeho klíče?`)) {
          setProducts(prev => prev.filter(p => p.id !== id));
          setKeys(prev => prev.filter(k => k.productId !== id)); // Smazat i klíče
          onLog(`Smazán produkt ${name}`);
      }
  };

  // --- KEY MANAGEMENT ---

  const getKeysForProduct = (productId: string) => keys.filter(k => k.productId === productId);

  const handleAddKey = () => {
    if (!selectedProductKeys || !newKeyCode.trim()) return;
    const newKey: LicenseKey = { 
      id: Math.random().toString(36).substr(2, 9), 
      code: newKeyCode.trim(), 
      productId: selectedProductKeys.id, 
      activationsUsed: 0, 
      activationsMax: newKeyActivations, 
      isUsed: false, 
      isActive: true,
      source: 'LOCAL'
    };
    setKeys(prev => [...prev, newKey]);
    
    // Update count in product
    setProducts(prev => prev.map(p => 
      p.id === selectedProductKeys.id 
      ? { ...p, totalKeys: p.totalKeys + 1, availableKeys: p.availableKeys + 1 } 
      : p
    ));
    
    onLog(`Přidán klíč k: ${selectedProductKeys.name}`);
    setNewKeyCode('');
    setNewKeyActivations(1);
  };

  const deleteKey = (keyId: string) => {
     if(!selectedProductKeys) return;
     setKeys(prev => prev.filter(k => k.id !== keyId));
     setProducts(prev => prev.map(p => 
        p.id === selectedProductKeys.id 
        ? { ...p, totalKeys: p.totalKeys - 1, availableKeys: p.availableKeys - 1 } 
        : p
      ));
  };

  // --- SYNC ---

  const handleSyncWithNody = async () => {
    setIsSyncing(true);
    try {
        const res = await fetch('/api/products', { method: 'POST' });
        const data = await res.json();
        if (data.success && data.products) {
            setProducts(data.products);
            onLog(`Synchronizace s Nody API dokončena. (${data.message})`);
            alert(data.message);
        } else {
            alert('Chyba při synchronizaci: ' + (data.error || 'Neznámá chyba'));
        }
    } catch (e) {
        alert('Chyba spojení s backendem.');
    }
    setIsSyncing(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Header */}
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <h3 className="text-xl font-bold text-slate-800 tracking-tight">Katalog produktů</h3>
          <p className="text-sm text-slate-400 font-semibold mt-1 uppercase tracking-widest">
            {products.length} položek v evidenci
          </p>
        </div>
        <div className="flex gap-3">
            <button 
              onClick={handleSyncWithNody}
              disabled={isSyncing}
              className={`flex items-center gap-2.5 px-6 py-3 border border-slate-200 text-slate-700 rounded-xl text-[11px] font-bold hover:bg-slate-50 transition-all uppercase tracking-widest active:scale-95 ${isSyncing ? 'opacity-50 cursor-not-allowed' : ''}`}
            >
              <CloudDownload className={`w-4 h-4 ${isSyncing ? 'animate-bounce' : ''}`} /> 
              {isSyncing ? 'Stahuji...' : 'Sync Nody'}
            </button>
            <button 
              onClick={openCreateModal}
              className="flex items-center gap-2.5 px-6 py-3 bg-blue-600 text-white rounded-xl text-[11px] font-bold hover:bg-blue-700 shadow-lg shadow-blue-600/10 transition-all uppercase tracking-widest active:scale-95"
            >
              <Plus className="w-4 h-4" /> Přidat produkt
            </button>
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-50 border-b border-slate-200">
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Produkt</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Cena / Marže</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest">Identifikátory</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-center">Sklad (Local/Nody)</th>
              <th className="px-6 py-4 text-[10px] font-bold text-slate-500 uppercase tracking-widest text-right">Akce</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {products.map((p) => (
              <tr key={p.id} className="hover:bg-slate-50/30 transition-colors group">
                <td className="px-6 py-4">
                  <div className="flex items-center gap-4">
                      <div className="w-10 h-10 bg-slate-100 rounded-lg flex items-center justify-center overflow-hidden border border-slate-200 shrink-0 relative">
                        {p.image ? (
                          <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
                        ) : (
                          <Package className="w-5 h-5 text-slate-300" />
                        )}
                        {p.autoFulfill && (
                            <div className="absolute top-0 right-0 bg-emerald-500 w-2.5 h-2.5 rounded-bl-lg z-10" title="Auto-Fulfill zapnuto"></div>
                        )}
                      </div>
                      <div>
                          <p className="font-bold text-slate-800 text-sm">{p.name}</p>
                          <div className="flex gap-2 mt-1">
                              {p.autoFulfill && <span className="text-[9px] bg-emerald-50 text-emerald-600 px-1.5 rounded font-bold uppercase tracking-tighter flex items-center gap-0.5"><Zap className="w-2 h-2"/> Auto</span>}
                          </div>
                      </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                   <div className="flex flex-col">
                      <span className="text-sm font-bold text-slate-800">{p.price} Kč</span>
                      {p.buyPrice && (
                          <span className="text-[10px] font-bold text-slate-400">
                             Nákup: {p.buyPrice} Kč
                          </span>
                      )}
                   </div>
                </td>
                <td className="px-6 py-4">
                   <div className="flex flex-col gap-1">
                      <span className="font-mono text-xs font-bold text-slate-600">{p.ean || '---'}</span>
                      {p.nodyId && (
                          <span className="inline-flex items-center gap-1 text-[9px] font-bold text-blue-500 bg-blue-50 px-1.5 py-0.5 rounded w-fit">
                              <Database className="w-3 h-3" /> NODY
                          </span>
                      )}
                   </div>
                </td>
                <td className="px-6 py-4 text-center">
                  <div className="flex items-center justify-center gap-2">
                      <span className={`px-2 py-1 rounded text-[11px] font-bold ${p.availableKeys > 0 ? 'bg-slate-100 text-slate-700' : 'bg-rose-50 text-rose-600'}`}>
                        {p.availableKeys} ks
                      </span>
                      <span className="text-slate-300">/</span>
                      <span className={`text-[11px] font-bold ${p.remoteStock && p.remoteStock > 0 ? 'text-blue-600' : 'text-slate-300'}`}>
                        {p.remoteStock || '-'} ext
                      </span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button 
                        onClick={() => setSelectedProductKeys(p)}
                        className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Spravovat klíče"
                    >
                        <Hash className="w-4 h-4" />
                    </button>
                    <button 
                        onClick={() => openEditModal(p)}
                        className="p-2 text-slate-400 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors" title="Upravit produkt"
                    >
                        <Pencil className="w-4 h-4" />
                    </button>
                    <button 
                        onClick={() => handleDeleteProduct(p.id, p.name)}
                        className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Smazat produkt"
                    >
                        <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* --- MODAL: PRODUKT (CREATE / EDIT) --- */}
      {isProductModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in zoom-in-95 duration-200">
          <div className="bg-white w-full max-w-2xl rounded-xl shadow-2xl border border-slate-200 flex flex-col max-h-[90vh]">
            <div className="flex justify-between items-center p-6 border-b border-slate-100">
               <div className="flex items-center gap-3">
                   <div className="bg-blue-600 p-2 rounded-lg">
                       {editMode ? <Pencil className="w-5 h-5 text-white" /> : <Plus className="w-5 h-5 text-white" />}
                   </div>
                   <h3 className="text-lg font-bold text-slate-800">
                       {editMode ? `Úprava: ${editMode.name}` : 'Nový produkt'}
                   </h3>
               </div>
               <button onClick={() => setIsProductModalOpen(false)}><X className="w-5 h-5 text-slate-400 hover:text-slate-600" /></button>
            </div>
            
            <div className="p-8 overflow-y-auto space-y-6">
              
              <div className="flex gap-6">
                 {/* Image Preview */}
                 <div className="w-32 h-32 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-center overflow-hidden shrink-0">
                    {formData.image ? (
                        <img src={formData.image} alt="Preview" className="w-full h-full object-cover" />
                    ) : (
                        <ImageIcon className="w-8 h-8 text-slate-300" />
                    )}
                 </div>
                 
                 <div className="flex-1 space-y-4">
                     <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Název produktu</label>
                        <input 
                            type="text" 
                            value={formData.name}
                            onChange={e => setFormData({...formData, name: e.target.value})}
                            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:outline-none focus:border-blue-500"
                            placeholder="Např. Windows 11 Pro"
                        />
                     </div>
                     <div>
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">URL Obrázku</label>
                        <input 
                            type="text" 
                            value={formData.image}
                            onChange={e => setFormData({...formData, image: e.target.value})}
                            className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-600 focus:outline-none focus:border-blue-500"
                            placeholder="https://..."
                        />
                     </div>
                 </div>
              </div>

              <div className="grid grid-cols-2 gap-6">
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Prodejní cena (Kč)</label>
                    <div className="relative">
                        <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input 
                            type="number" 
                            value={formData.price}
                            onChange={e => setFormData({...formData, price: Number(e.target.value)})}
                            className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800"
                        />
                    </div>
                 </div>
                 <div>
                    <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">EAN / Kód</label>
                    <div className="relative">
                        <Barcode className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                        <input 
                            type="text" 
                            value={formData.ean}
                            onChange={e => setFormData({...formData, ean: e.target.value})}
                            className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-mono font-semibold text-slate-800"
                        />
                    </div>
                 </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Popis produktu</label>
                <textarea 
                    rows={3}
                    value={formData.description}
                    onChange={e => setFormData({...formData, description: e.target.value})}
                    className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm text-slate-600 focus:outline-none focus:border-blue-500"
                ></textarea>
              </div>

              <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 flex items-center justify-between cursor-pointer" onClick={() => setFormData({...formData, autoFulfill: !formData.autoFulfill})}>
                 <div className="flex items-center gap-3">
                    <div className={`p-2 rounded-lg ${formData.autoFulfill ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-200 text-slate-400'}`}>
                        <Zap className="w-5 h-5" />
                    </div>
                    <div>
                        <p className="text-sm font-bold text-slate-800">Automatický nákup (Auto-Fulfill)</p>
                        <p className="text-xs text-slate-500">Pokud dojde lokální sklad, pokusit se koupit licenci na Nody API.</p>
                    </div>
                 </div>
                 <div className={`w-12 h-6 rounded-full relative transition-colors ${formData.autoFulfill ? 'bg-emerald-500' : 'bg-slate-300'}`}>
                     <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${formData.autoFulfill ? 'right-1' : 'left-1'}`}></div>
                 </div>
              </div>

            </div>
            
            <div className="p-6 border-t border-slate-100 bg-slate-50 flex justify-end gap-3">
               <button onClick={() => setIsProductModalOpen(false)} className="px-6 py-3 text-slate-500 font-bold text-xs uppercase hover:text-slate-800">Zrušit</button>
               <button onClick={handleSaveProduct} className="px-8 py-3 bg-slate-900 text-white rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-slate-800 shadow-lg active:scale-95 transition-all">
                  <Save className="w-4 h-4 inline mr-2" /> Uložit produkt
               </button>
            </div>
          </div>
        </div>
      )}

      {/* --- MODAL: KLÍČE (KEY MANAGEMENT) --- */}
      {selectedProductKeys && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-3xl rounded-xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-10 py-6 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-white border border-slate-200 rounded-xl p-2 flex items-center justify-center">
                   {selectedProductKeys.image ? <img src={selectedProductKeys.image} alt="" className="max-w-full max-h-full" /> : <Package className="w-6 h-6 text-slate-300" />}
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900 tracking-tight">{selectedProductKeys.name}</h3>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">
                     Správa skladu licencí
                  </p>
                </div>
              </div>
              <button onClick={() => setSelectedProductKeys(null)} className="p-2.5 hover:bg-slate-200 rounded-xl transition-colors"><X className="w-6 h-6 text-slate-400" /></button>
            </div>
            
            <div className="p-10 flex-1 overflow-y-auto space-y-8 custom-scrollbar">
              
              {/* Add Key Form */}
              <div className="bg-blue-600 p-6 rounded-xl shadow-xl shadow-blue-600/10 space-y-4">
                <div className="flex items-center gap-2 text-white">
                  <Plus className="w-4 h-4" />
                  <h4 className="text-xs font-bold uppercase tracking-widest">Vložit nový klíč</h4>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                  <div className="md:col-span-2 space-y-1">
                    <label className="text-[9px] font-bold text-blue-100 uppercase tracking-widest pl-1">Licenční kód</label>
                    <input type="text" value={newKeyCode} onChange={(e) => setNewKeyCode(e.target.value)} placeholder="ABCDE-12345..." className="w-full bg-white/10 border border-white/20 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:bg-white/20 transition-all placeholder:text-white/40 font-mono font-bold" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[9px] font-bold text-blue-100 uppercase tracking-widest pl-1">Aktivace</label>
                    <input type="number" value={newKeyActivations} onChange={(e) => setNewKeyActivations(parseInt(e.target.value) || 1)} className="w-full bg-white/10 border border-white/20 rounded-lg p-2.5 text-sm text-white focus:outline-none focus:bg-white/20 transition-all font-bold" />
                  </div>
                  <button onClick={handleAddKey} className="w-full py-2.5 bg-white text-blue-600 rounded-lg text-xs font-bold hover:bg-blue-50 transition-all shadow-lg active:scale-95 uppercase tracking-widest">Vložit</button>
                </div>
              </div>

              {/* Keys List */}
              <div className="space-y-3">
                <div className="flex justify-between items-center border-b border-slate-100 pb-2">
                   <h4 className="text-[10px] font-bold text-slate-500 uppercase tracking-widest flex items-center gap-2"><Hash className="w-3.5 h-3.5" /> Dostupné klíče ({getKeysForProduct(selectedProductKeys.id).filter(k => !k.isUsed).length})</h4>
                </div>
                <div className="grid grid-cols-1 gap-2">
                  {getKeysForProduct(selectedProductKeys.id).filter(k => !k.isUsed).length > 0 ? (
                    getKeysForProduct(selectedProductKeys.id).filter(k => !k.isUsed).map(key => (
                      <div key={key.id} className="p-3 border rounded-lg flex items-center justify-between bg-white border-slate-100 shadow-sm group hover:border-blue-200 transition-colors">
                        <code className="text-[13px] font-mono font-bold text-slate-700 select-all">{key.code}</code>
                        <div className="flex items-center gap-4">
                          <span className="text-[9px] font-bold text-slate-300 uppercase tracking-widest">Max aktivací: {key.activationsMax}</span>
                          <button onClick={() => deleteKey(key.id)} className="p-1.5 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"><Trash2 className="w-4 h-4" /></button>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="py-8 text-center border-2 border-dashed border-slate-100 rounded-xl">
                      <p className="text-xs text-slate-400 font-semibold uppercase tracking-widest">Žádné volné klíče</p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <div className="px-10 py-5 bg-slate-50 border-t border-slate-200 flex justify-end">
              <button onClick={() => setSelectedProductKeys(null)} className="px-8 py-3 bg-slate-800 text-white rounded-xl text-[11px] font-bold uppercase tracking-widest hover:bg-slate-700 transition-all">Zavřít</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Warehouse;
