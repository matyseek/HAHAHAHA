
import React, { useState, useEffect } from 'react';
import { Save, Server, Mail, Shield, Zap, Globe, Key, AlertCircle } from 'lucide-react';

interface SettingsProps {
  onLog: (action: string) => void;
}

const SettingsPage: React.FC<SettingsProps> = ({ onLog }) => {
  const [activeTab, setActiveTab] = useState<'GENERAL' | 'NODY' | 'EMAIL'>('GENERAL');
  const [loading, setLoading] = useState(false);
  
  // General
  const [storeName, setStoreName] = useState('Můj Digitální Obchod');
  const [adminEmail, setAdminEmail] = useState('');

  // Nody API
  const [nodyApiUrl, setNodyApiUrl] = useState('https://api.nody.cz/v1');
  const [nodyApiKey, setNodyApiKey] = useState('');
  const [autoPurchase, setAutoPurchase] = useState(false); // Globální přepínač pro nákupy
  const [minCreditWarning, setMinCreditWarning] = useState('1000');

  // SMTP
  const [smtpHost, setSmtpHost] = useState('');
  const [smtpUser, setSmtpUser] = useState('');
  const [smtpPass, setSmtpPass] = useState('');

  // Načíst nastavení
  useEffect(() => {
    fetch('/api/settings')
      .then(res => res.json())
      .then(data => {
        if (data.storeName) setStoreName(data.storeName);
        if (data.nody) {
            setNodyApiUrl(data.nody.apiUrl || 'https://api.nody.cz/v1');
            setNodyApiKey(data.nody.apiKey || '');
            setAutoPurchase(data.nody.autoPurchase || false);
        }
        if (data.smtp) {
            setSmtpHost(data.smtp.host);
            setSmtpUser(data.smtp.user);
            setSmtpPass(data.smtp.pass);
        }
      })
      .catch(console.error);
  }, []);

  const handleSave = async () => {
    setLoading(true);
    const payload = {
        storeName,
        nody: {
            apiUrl: nodyApiUrl,
            apiKey: nodyApiKey,
            autoPurchase,
            minCreditWarning: parseInt(minCreditWarning)
        },
        smtp: {
            host: smtpHost,
            user: smtpUser,
            pass: smtpPass
        }
    };

    try {
        await fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        onLog('Aktualizace systémového nastavení');
        alert('Nastavení uloženo.');
    } catch (e) {
        alert('Chyba ukládání.');
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
        {/* Tabs */}
        <div className="flex gap-4 border-b border-slate-100 pb-1 mb-6">
            <button onClick={() => setActiveTab('GENERAL')} className={`px-4 py-2 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors ${activeTab === 'GENERAL' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-400'}`}>Obecné</button>
            <button onClick={() => setActiveTab('NODY')} className={`px-4 py-2 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors ${activeTab === 'NODY' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-400'}`}>Nody Integrace</button>
            <button onClick={() => setActiveTab('EMAIL')} className={`px-4 py-2 text-xs font-bold uppercase tracking-widest border-b-2 transition-colors ${activeTab === 'EMAIL' ? 'border-blue-600 text-blue-600' : 'border-transparent text-slate-400'}`}>SMTP & E-mail</button>
        </div>

        <div className="max-w-3xl">
          {activeTab === 'GENERAL' && (
            <div className="space-y-6">
               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Název obchodu</label>
                  <input type="text" value={storeName} onChange={(e) => setStoreName(e.target.value)} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-semibold" />
               </div>
            </div>
          )}

          {activeTab === 'NODY' && (
            <div className="space-y-6">
               <div className="bg-blue-50 p-4 rounded-xl border border-blue-100 flex gap-4 items-start">
                   <Globe className="w-6 h-6 text-blue-600 mt-1" />
                   <div>
                       <h4 className="text-sm font-bold text-blue-900">Nody.cz - Váš digitální sklad</h4>
                       <p className="text-xs text-blue-700 mt-1">Zde nastavte API klíč z administrace Nody.cz. To umožní stahovat produkty a automaticky nakupovat licence.</p>
                   </div>
               </div>

               <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">API URL</label>
                      <input type="text" value={nodyApiUrl} onChange={(e) => setNodyApiUrl(e.target.value)} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-mono text-sm" />
                   </div>
                   <div>
                      <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">API Key (Token)</label>
                      <div className="relative">
                          <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                          <input type="text" value={nodyApiKey} onChange={(e) => setNodyApiKey(e.target.value)} placeholder="Vložte API klíč..." className="w-full pl-10 p-3 bg-slate-50 border border-slate-200 rounded-xl font-mono text-sm" />
                      </div>
                   </div>
               </div>

               <div className="flex items-center justify-between p-4 border border-slate-200 rounded-xl">
                   <div className="flex items-center gap-3">
                       <div className={`p-2 rounded-lg ${autoPurchase ? 'bg-emerald-100 text-emerald-600' : 'bg-slate-100 text-slate-400'}`}>
                           <Zap className="w-5 h-5" />
                       </div>
                       <div>
                           <p className="text-sm font-bold text-slate-800">Globální automatický nákup</p>
                           <p className="text-xs text-slate-500">Pokud je zapnuto, systém se pokusí koupit licenci na Nody, pokud není v lokálním skladu.</p>
                       </div>
                   </div>
                   <button 
                    onClick={() => setAutoPurchase(!autoPurchase)}
                    className={`w-12 h-6 rounded-full relative transition-colors ${autoPurchase ? 'bg-emerald-500' : 'bg-slate-300'}`}
                   >
                       <div className={`w-4 h-4 bg-white rounded-full absolute top-1 transition-all ${autoPurchase ? 'right-1' : 'left-1'}`}></div>
                   </button>
               </div>

               <div>
                  <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-2">Upozornit při kreditu pod (Kč)</label>
                  <input type="number" value={minCreditWarning} onChange={(e) => setMinCreditWarning(e.target.value)} className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl font-semibold" />
               </div>
            </div>
          )}

          {activeTab === 'EMAIL' && (
            <div className="space-y-6">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
                    <p className="text-xs text-slate-500 mb-4">SMTP údaje jsou potřeba pro odesílání licencí koncovým zákazníkům.</p>
                    <div className="grid grid-cols-1 gap-4">
                        <input type="text" placeholder="SMTP Host (např. smtp.office365.com)" value={smtpHost} onChange={(e) => setSmtpHost(e.target.value)} className="w-full p-3 bg-white border border-slate-200 rounded-xl text-sm" />
                        <input type="text" placeholder="Uživatel (email)" value={smtpUser} onChange={(e) => setSmtpUser(e.target.value)} className="w-full p-3 bg-white border border-slate-200 rounded-xl text-sm" />
                        <input type="password" placeholder="Heslo" value={smtpPass} onChange={(e) => setSmtpPass(e.target.value)} className="w-full p-3 bg-white border border-slate-200 rounded-xl text-sm" />
                    </div>
                </div>
            </div>
          )}

          <div className="mt-8 flex justify-end">
             <button onClick={handleSave} disabled={loading} className="px-8 py-3 bg-slate-900 text-white rounded-xl text-xs font-bold uppercase tracking-widest hover:bg-slate-800 transition-colors">
                {loading ? 'Ukládám...' : 'Uložit změny'}
             </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPage;
