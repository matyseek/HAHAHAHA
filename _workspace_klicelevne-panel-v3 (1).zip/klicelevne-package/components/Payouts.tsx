
import React, { useState } from 'react';
import { MOCK_PAYOUTS, MOCK_PANEL_USERS } from '../constants';
import { ActionLog } from '../types';
import { 
  ArrowUpCircle, 
  ArrowDownCircle, 
  Wallet, 
  Plus, 
  Users, 
  Shield, 
  Activity,
  Trash2,
  Lock,
  Mail
} from 'lucide-react';

interface PayoutsProps {
  isAdmin: boolean;
  logs: ActionLog[];
}

const Payouts: React.FC<PayoutsProps> = ({ isAdmin, logs }) => {
  const [payouts] = useState(MOCK_PAYOUTS);
  const [panelUsers] = useState(MOCK_PANEL_USERS);

  return (
    <div className="space-y-10 pb-10">
      {/* Finance Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[2rem] text-white shadow-xl shadow-blue-100 relative overflow-hidden group">
          <div className="relative z-10">
            <div className="flex justify-between items-center mb-6">
              <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md">
                <Wallet className="w-6 h-6 text-white" />
              </div>
              <p className="text-white/60 text-[10px] font-black uppercase tracking-widest">Celková bilance</p>
            </div>
            <p className="text-4xl font-black mb-1">125 400 Kč</p>
          </div>
          <div className="absolute -right-8 -bottom-8 w-48 h-48 bg-white/10 rounded-full blur-2xl"></div>
        </div>

        <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-center">
            <div className="p-3 bg-emerald-50 rounded-2xl">
              <ArrowUpCircle className="w-6 h-6 text-emerald-500" />
            </div>
            <span className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest">Příjmy</span>
          </div>
          <div className="mt-6">
            <p className="text-3xl font-black text-slate-800">420 500 Kč</p>
            <p className="text-slate-400 text-[10px] font-bold mt-1 uppercase tracking-widest">Celkem za kvartál</p>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[2rem] border border-slate-200 shadow-sm flex flex-col justify-between">
          <div className="flex justify-between items-center">
            <div className="p-3 bg-red-50 rounded-2xl">
              <ArrowDownCircle className="w-6 h-6 text-red-500" />
            </div>
            <span className="px-3 py-1 bg-red-50 text-red-600 rounded-full text-[10px] font-black uppercase tracking-widest">Výdaje</span>
          </div>
          <div className="mt-6">
            <p className="text-3xl font-black text-slate-800">95 200 Kč</p>
            <p className="text-slate-400 text-[10px] font-bold mt-1 uppercase tracking-widest">Celkem za kvartál</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Správa uživatelů panelu - Jen pro ADMINA */}
        <div className={`bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden ${!isAdmin ? 'opacity-50 pointer-events-none' : ''}`}>
           <div className="p-8 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
             <div className="flex items-center gap-3">
               <Shield className="w-6 h-6 text-blue-600" />
               <h3 className="text-lg font-black text-slate-800 tracking-tight">Správa uživatelů panelu</h3>
             </div>
             {isAdmin && <button className="p-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"><Plus className="w-5 h-5" /></button>}
           </div>
           
           {!isAdmin && (
             <div className="p-8 text-center bg-slate-50">
                <Lock className="w-10 h-10 text-slate-300 mx-auto mb-3" />
                <p className="text-sm font-bold text-slate-400 uppercase tracking-widest">Pouze pro administrátory</p>
             </div>
           )}

           {isAdmin && (
             <div className="divide-y divide-slate-50">
                {panelUsers.map(user => (
                  <div key={user.id} className="p-6 flex items-center justify-between group hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center font-black text-slate-400 text-xs">
                        {user.username[0].toUpperCase()}
                      </div>
                      <div>
                        <p className="font-bold text-slate-800 text-sm">{user.username}</p>
                        <span className="text-[10px] font-black text-blue-600 uppercase tracking-tighter">{user.role}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"><Mail className="w-4 h-4" /></button>
                      <button className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                    </div>
                  </div>
                ))}
             </div>
           )}
        </div>

        {/* Audit Log / Historie aktivit */}
        <div className="bg-white rounded-[2rem] border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="p-8 border-b border-slate-100 flex items-center gap-3 bg-slate-50/50">
             <Activity className="w-6 h-6 text-orange-500" />
             <h3 className="text-lg font-black text-slate-800 tracking-tight">Historie aktivit (Audit)</h3>
          </div>
          <div className="p-0 flex-1">
             <div className="overflow-x-auto">
               <table className="w-full text-left">
                  <thead className="bg-white border-b border-slate-100">
                    <tr>
                      <th className="px-8 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Uživatel</th>
                      <th className="px-8 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest">Akce</th>
                      <th className="px-8 py-4 text-[9px] font-black text-slate-400 uppercase tracking-widest text-right">Čas</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-50">
                    {logs.map(log => (
                      <tr key={log.id} className="text-[11px] hover:bg-slate-50/50 transition-colors">
                        <td className="px-8 py-3 font-bold text-slate-600">{log.username}</td>
                        <td className="px-8 py-3 text-slate-500 font-medium">{log.action}</td>
                        <td className="px-8 py-3 text-right text-slate-400 font-bold">{log.timestamp.split(',')[1] || log.timestamp}</td>
                      </tr>
                    ))}
                  </tbody>
               </table>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payouts;
