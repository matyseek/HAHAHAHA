const nodemailer = require('nodemailer');

class EmailService {
  constructor() {
    this.transporter = null;
  }

  // Initialize transporter with SMTP settings
  async initTransporter(smtpConfig) {
    try {
      console.log('[EMAIL] Initializing SMTP transporter...');
      console.log(`[EMAIL] Host: ${smtpConfig.host}`);
      console.log(`[EMAIL] User: ${smtpConfig.user}`);
      console.log(`[EMAIL] Port: ${smtpConfig.port || 587}`);
      
      this.transporter = nodemailer.createTransport({
        host: smtpConfig.host || 'smtp.office365.com',
        port: smtpConfig.port || 587,
        secure: smtpConfig.port === 465, // true for 465, false for other ports
        auth: {
          user: smtpConfig.user,
          pass: smtpConfig.pass
        },
        tls: {
          rejectUnauthorized: false // For self-signed certificates
        }
      });

      // Verify connection
      await this.transporter.verify();
      console.log('[EMAIL] SMTP connection verified successfully');
      return true;
    } catch (error) {
      console.error('[EMAIL] SMTP connection failed:', error.message);
      console.error('[EMAIL] Error details:', error);
      throw error;
    }
  }

  // Send license key email to customer
  async sendLicenseEmail(options) {
    const { 
      customerEmail, 
      customerName, 
      orderNumber, 
      productName, 
      licenseKey,
      storeName 
    } = options;

    if (!this.transporter) {
      throw new Error('Email transporter not initialized');
    }

    const mailOptions = {
      from: `"${storeName || 'Digital Store'}" <${this.transporter.options.auth.user}>`,
      to: customerEmail,
      subject: `Vaše licence pro ${productName} - Objednávka ${orderNumber}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #2563eb; color: white; padding: 20px; text-align: center; border-radius: 10px 10px 0 0; }
            .content { background: #f9fafb; padding: 30px; border: 1px solid #e5e7eb; }
            .key-box { background: #dbeafe; border: 2px solid #3b82f6; padding: 20px; text-align: center; margin: 20px 0; border-radius: 8px; }
            .key-code { font-size: 24px; font-weight: bold; color: #1e40af; letter-spacing: 2px; }
            .footer { background: #f3f4f6; padding: 20px; text-align: center; font-size: 12px; color: #6b7280; border-radius: 0 0 10px 10px; }
            .button { display: inline-block; background: #2563eb; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; margin-top: 10px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1>Děkujeme za nákup!</h1>
            </div>
            <div class="content">
              <p>Dobrý den <strong>${customerName}</strong>,</p>
              <p>Děkujeme za Vaši objednávku <strong>#${orderNumber}</strong>. Zde jsou Vaše licenční údaje:</p>
              
              <h3>${productName}</h3>
              
              <div class="key-box">
                <p style="margin: 0 0 10px 0; font-weight: bold;">Váš aktivační klíč:</p>
                <div class="key-code">${licenseKey}</div>
              </div>
              
              <h4>Jak aktivovat produkt:</h4>
              <ol>
                <li>Otevřete produkt, který jste zakoupili</li>
                <li>Najděte sekci pro aktivaci produktu</li>
                <li>Zadejte výše uvedený aktivační klíč</li>
                <li>Pokračujte podle pokynů na obrazovce</li>
              </ol>
              
              <p><strong>Důležité:</strong></p>
              <ul>
                <li>Tento klíč lze použít pouze jednou</li>
                <li>Ponechte si tento email pro budoucí reference</li>
                <li>Pokud máte problémy, kontaktujte naši podporu</li>
              </ul>
              
              <p style="margin-top: 30px;">
                S pozdravem,<br>
                <strong>${storeName || 'Digital Store'}</strong>
              </p>
            </div>
            <div class="footer">
              <p>Tento email byl odeslán automaticky. Prosím neodpovídejte na něj.</p>
              <p>Pokud jste tento email neobjednali, prosím ignorujte ho.</p>
            </div>
          </div>
        </body>
        </html>
      `,
      text: `
Děkujeme za nákup!

Dobrý den ${customerName},

Děkujeme za Vaši objednávku #${orderNumber}.

Produkt: ${productName}
Aktivační klíč: ${licenseKey}

Jak aktivovat produkt:
1. Otevřete produkt, který jste zakoupili
2. Najděte sekci pro aktivaci produktu
3. Zadejte aktivační klíč: ${licenseKey}
4. Pokračujte podle pokynů na obrazovce

Důležité:
- Tento klíč lze použít pouze jednou
- Ponechte si tento email pro budoucí reference
- Pokud máte problémy, kontaktujte naši podporu

S pozdravem,
${storeName || 'Digital Store'}
      `
    };

    try {
      console.log(`[EMAIL] Sending license email to ${customerEmail}`);
      const info = await this.transporter.sendMail(mailOptions);
      console.log('[EMAIL] License email sent successfully:', info.messageId);
      return { success: true, messageId: info.messageId };
    } catch (error) {
      console.error('[EMAIL] Failed to send email:', error.message);
      console.error('[EMAIL] Error details:', error);
      throw error;
    }
  }

  // Send notification email to admin
  async sendAdminNotification(options) {
    const { subject, message, adminEmail, storeName } = options;

    if (!this.transporter) {
      throw new Error('Email transporter not initialized');
    }

    const mailOptions = {
      from: `"${storeName || 'Digital Store'} System" <${this.transporter.options.auth.user}>`,
      to: adminEmail,
      subject: `[${storeName || 'Digital Store'}] ${subject}`,
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="utf-8">
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #dc2626; color: white; padding: 15px; border-radius: 8px 8px 0 0; }
            .content { background: #fef2f2; padding: 20px; border: 1px solid #fecaca; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h2>⚠️ Systémové upozornění</h2>
            </div>
            <div class="content">
              <p>${message}</p>
              <p><strong>Čas:</strong> ${new Date().toLocaleString('cs-CZ')}</p>
            </div>
          </div>
        </body>
        </html>
      `
    };

    try {
      const info = await this.transporter.sendMail(mailOptions);
      console.log('[EMAIL] Admin notification sent:', info.messageId);
      return { success: true };
    } catch (error) {
      console.error('[EMAIL] Failed to send admin notification:', error);
      throw error;
    }
  }
}

module.exports = new EmailService();