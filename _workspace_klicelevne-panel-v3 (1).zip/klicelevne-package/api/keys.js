
const { loadDb, saveDb } = require('./db');

module.exports = async function handler(request, response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    
    try {
        const db = await loadDb();

        if (request.method === 'GET') {
            return response.status(200).json(db.keys || []);
        }

        if (request.method === 'POST') {
            const newKey = request.body;
            if (!newKey.code || !newKey.productId) {
                return response.status(400).json({ error: 'Chybí kód nebo ID produktu' });
            }
            
            db.keys.push(newKey);
            await saveDb(db);
            return response.status(200).json({ success: true, key: newKey });
        }

        if (request.method === 'DELETE') {
            const { id } = request.query;
            if (!id) return response.status(400).json({ error: 'Chybí ID klíče' });
            
            db.keys = db.keys.filter(k => k.id !== id);
            await saveDb(db);
            return response.status(200).json({ success: true });
        }

        return response.status(405).json({ error: 'Method not allowed' });
    } catch (error) {
        console.error(error);
        if (!response.headersSent) {
            return response.status(500).json({ error: error.message });
        }
    }
};
