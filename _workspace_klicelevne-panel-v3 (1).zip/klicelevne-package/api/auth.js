const { loadDb, saveDb } = require('./db');

// Simple JWT-like token generation (in production, use proper JWT)
function generateToken(userId) {
  return Buffer.from(`${userId}:${Date.now()}`).toString('base64');
}

// Verify token
function verifyToken(token) {
  try {
    const decoded = Buffer.from(token, 'base64').toString();
    const [userId] = decoded.split(':');
    return userId;
  } catch {
    return null;
  }
}

module.exports = async function handler(request, response) {
  response.setHeader('Access-Control-Allow-Origin', '*');
  response.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (request.method === 'OPTIONS') {
    return response.status(200).end();
  }

  const { method } = request;

  if (method === 'POST') {
    // Handle login
    const { username, password } = request.body;

    if (!username || !password) {
      return response.status(400).json({ error: 'Chybí uživatelské jméno nebo heslo' });
    }

    try {
      const db = await loadDb();
      
      // Check if user exists in database
      const user = db.users?.find(u => u.username === username);

      if (!user) {
        return response.status(401).json({ error: 'Neplatné přihlašovací údaje' });
      }

      // Verify password (in production, use bcrypt)
      if (user.password !== password) {
        return response.status(401).json({ error: 'Neplatné přihlašovací údaje' });
      }

      // Generate token
      const token = generateToken(user.id);

      // Return user info and token
      return response.status(200).json({
        success: true,
        token,
        user: {
          id: user.id,
          username: user.username,
          role: user.role || 'ADMIN'
        }
      });
    } catch (error) {
      console.error('[AUTH ERROR]', error);
      return response.status(500).json({ error: 'Chyba při přihlášení' });
    }
  } else {
    return response.status(405).json({ error: 'Method not allowed' });
  }
};