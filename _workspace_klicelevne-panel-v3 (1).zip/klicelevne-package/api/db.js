
const fs = require('fs');
const path = require('path');

// Detekce prostředí
const IS_VERCEL = process.env.VERCEL === '1' || !!process.env.KV_REST_API_URL;
// Database file bude vždy v kořeni projektu nebo v /tmp na Vercelu
const DB_FILE = IS_VERCEL ? '/tmp/database.json' : path.join(process.cwd(), 'database.json');

const INITIAL_DATA = {
    users: [
        {
            id: 'admin',
            username: 'admin',
            password: 'Olda@2002', // Real password for admin
            role: 'ADMIN',
            email: 'podpora@klicelevne.cz',
            createdAt: new Date().toISOString()
        }
    ],
    orders: [],
    keys: [],
    products: [],
    settings: {
        storeName: 'KliceLevne.cz',
        nody: {
            apiUrl: 'https://api.nody.cz/v1',
            apiKey: 'UmhgmjlIl6hhROY3R6hoBlPk0RVz8MLY6aF5MQswsmWXsByw2Jtry6TJkb2s',
            autoPurchase: false,
            minCreditWarning: 1000
        },
        smtp: {
            host: 'smtp.office365.com',
            port: 587,
            user: 'podpora@klicelevne.cz',
            pass: 'Olda@2002'
        }
    },
    logs: []
};

async function loadDb() {
    let data = null;

    // 1. Vercel KV - jen pokud jsme na Vercelu a máme URL
    if (IS_VERCEL && process.env.KV_REST_API_URL) {
        try {
            // require dáváme dovnitř, aby se lokálně vůbec nespouštělo
            const { kv } = require('@vercel/kv');
            data = await kv.get('license_db');
        } catch (e) {
            console.error("[DB] KV Load Error:", e.message);
        }
    }
    
    // 2. Lokální soubor (fallback)
    if (!data) {
        if (fs.existsSync(DB_FILE)) {
            try {
                const fileData = fs.readFileSync(DB_FILE, 'utf8');
                data = JSON.parse(fileData);
            } catch (e) {
                console.error("[DB] Parse File Error:", e.message);
                data = { ...INITIAL_DATA };
            }
        } else {
            data = { ...INITIAL_DATA };
            // Vytvoříme soubor, pokud neexistuje
            try {
                fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
            } catch (err) {}
        }
    }

    // Garantujeme pole a objekty
    data.users = Array.isArray(data.users) ? data.users : INITIAL_DATA.users;
    data.orders = Array.isArray(data.orders) ? data.orders : [];
    data.keys = Array.isArray(data.keys) ? data.keys : [];
    data.products = Array.isArray(data.products) ? data.products : [];
    data.settings = data.settings || { ...INITIAL_DATA.settings };
    data.logs = Array.isArray(data.logs) ? data.logs : [];

    return data;
}

async function saveDb(data) {
    if (!data) return;

    // 1. Uložení do Vercel KV
    if (IS_VERCEL && process.env.KV_REST_API_URL) {
        try {
            const { kv } = require('@vercel/kv');
            await kv.set('license_db', data);
        } catch (e) {
            console.error("[DB] KV Save Error:", e.message);
        }
    }
    
    // 2. Uložení do lokálního souboru
    try {
        fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
    } catch (e) {
        console.error("[DB] File Save Error:", e.message);
    }
}

module.exports = { loadDb, saveDb };
