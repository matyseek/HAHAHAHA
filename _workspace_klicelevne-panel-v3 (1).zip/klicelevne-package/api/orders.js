const { loadDb, saveDb } = require('./db');
const NodyService = require('./nody');
const emailService = require('./email');

module.exports = async function handler(request, response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    
    if (request.method === 'POST') {
        try {
            const action = request.body.action;
            const db = await loadDb();
            const settings = db.settings || {};
            
            // Initialize Nody service if configured
            let nodyService = null;
            if (settings.nody?.apiKey) {
                nodyService = new NodyService(settings.nody.apiUrl, settings.nody.apiKey);
            }

            // Initialize email service if SMTP configured
            if (settings.smtp?.host && settings.smtp?.user && settings.smtp?.pass) {
                await emailService.initTransporter(settings.smtp);
            }

            if (action === 'sync') {
                // Sync orders from Shoptet (would need Shoptet API integration)
                return response.status(200).json({ success: true, message: 'Orders synced' });
            } 
            else if (action === 'process') {
                // Process an order - send license email
                const { orderId } = request.body;
                const order = db.orders.find(o => o.id === orderId);
                
                if (!order) {
                    return response.status(404).json({ error: 'Order not found' });
                }

                // Find available license key
                let licenseKey = null;
                for (const item of order.items) {
                    const key = db.keys.find(k => 
                        k.productId === item.nodyId && 
                        !k.isUsed && 
                        k.isActive
                    );
                    if (key) {
                        licenseKey = key;
                        key.isUsed = true;
                        key.usedDate = new Date().toISOString();
                        key.assignedToEmail = order.email;
                        key.orderNumber = order.orderNumber;
                        break;
                    }
                }

                if (!licenseKey) {
                    // Try to buy from Nody if auto-purchase is enabled
                    if (settings.nody?.autoPurchase && nodyService) {
                        for (const item of order.items) {
                            try {
                                const boughtKey = await nodyService.buyLicense(item.nodyId, order.orderNumber);
                                if (boughtKey) {
                                    licenseKey = {
                                        id: Date.now().toString(),
                                        code: boughtKey,
                                        productId: item.nodyId,
                                        isUsed: true,
                                        isActive: true,
                                        assignedToEmail: order.email,
                                        orderNumber: order.orderNumber,
                                        source: 'NODY',
                                        usedDate: new Date().toISOString()
                                    };
                                    db.keys.push(licenseKey);
                                    break;
                                }
                            } catch (error) {
                                console.error('[ORDER] Failed to buy license from Nody:', error);
                            }
                        }
                    }
                }

                if (!licenseKey) {
                    return response.status(400).json({ error: 'No available license key' });
                }

                // Send email
                if (emailService.transporter) {
                    try {
                        await emailService.sendLicenseEmail({
                            customerEmail: order.email,
                            customerName: order.customerName,
                            orderNumber: order.orderNumber,
                            productName: order.items[0].productName,
                            licenseKey: licenseKey.code,
                            storeName: settings.storeName
                        });
                        order.status = 'SENT';
                        order.licenseSent = true;
                        order.licenseSentDate = new Date().toISOString();
                    } catch (error) {
                        console.error('[ORDER] Failed to send email:', error);
                        order.status = 'EMAIL_FAILED';
                    }
                } else {
                    order.status = 'SENT';
                    order.licenseSent = true;
                }

                await saveDb(db);
                return response.status(200).json({ success: true, order, licenseKey });
            }
            else if (action === 'bulk_process') {
                // Process multiple orders
                const { orderIds } = request.body;
                const results = [];
                
                for (const orderId of orderIds) {
                    try {
                        // Reuse the process logic
                        const order = db.orders.find(o => o.id === orderId);
                        if (!order) {
                            results.push({ orderId, success: false, error: 'Not found' });
                            continue;
                        }

                        let licenseKey = null;
                        for (const item of order.items) {
                            const key = db.keys.find(k => 
                                k.productId === item.nodyId && 
                                !k.isUsed && 
                                k.isActive
                            );
                            if (key) {
                                licenseKey = key;
                                key.isUsed = true;
                                key.usedDate = new Date().toISOString();
                                key.assignedToEmail = order.email;
                                key.orderNumber = order.orderNumber;
                                break;
                            }
                        }

                        if (!licenseKey && settings.nody?.autoPurchase && nodyService) {
                            for (const item of order.items) {
                                try {
                                    const boughtKey = await nodyService.buyLicense(item.nodyId, order.orderNumber);
                                    if (boughtKey) {
                                        licenseKey = {
                                            id: Date.now().toString(),
                                            code: boughtKey,
                                            productId: item.nodyId,
                                            isUsed: true,
                                            isActive: true,
                                            assignedToEmail: order.email,
                                            orderNumber: order.orderNumber,
                                            source: 'NODY',
                                            usedDate: new Date().toISOString()
                                        };
                                        db.keys.push(licenseKey);
                                        break;
                                    }
                                } catch (error) {
                                    console.error('[ORDER] Failed to buy license:', error);
                                }
                            }
                        }

                        if (!licenseKey) {
                            results.push({ orderId, success: false, error: 'No key available' });
                            continue;
                        }

                        if (emailService.transporter) {
                            try {
                                await emailService.sendLicenseEmail({
                                    customerEmail: order.email,
                                    customerName: order.customerName,
                                    orderNumber: order.orderNumber,
                                    productName: order.items[0].productName,
                                    licenseKey: licenseKey.code,
                                    storeName: settings.storeName
                                });
                                order.status = 'SENT';
                                order.licenseSent = true;
                                order.licenseSentDate = new Date().toISOString();
                            } catch (error) {
                                order.status = 'EMAIL_FAILED';
                            }
                        } else {
                            order.status = 'SENT';
                            order.licenseSent = true;
                        }

                        results.push({ orderId, success: true, licenseKey: licenseKey.code });
                    } catch (error) {
                        results.push({ orderId, success: false, error: error.message });
                    }
                }

                await saveDb(db);
                return response.status(200).json({ success: true, results });
            }
            else {
                // Create new order
                const newOrder = request.body;
                newOrder.id = Date.now().toString();
                newOrder.createdAt = new Date().toISOString();
                newOrder.status = newOrder.status || 'PENDING';
                db.orders.push(newOrder);
                await saveDb(db);
                return response.status(200).json({ success: true, order: newOrder });
            }
        } catch (error) {
            console.error('[ORDERS ERROR]', error);
            return response.status(500).json({ error: error.message });
        }
    } else {
        // GET orders
        const db = await loadDb();
        return response.status(200).json(db.orders || []);
    }
};