const { loadDb, saveDb } = require('./db');
const NodyService = require('./nody');

module.exports = async function handler(request, response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    
    if (request.method === 'POST') {
        try {
            const action = request.body.action;
            const db = await loadDb();
            const settings = db.settings || {};

            if (action === 'sync_nody') {
                // Sync products from Nody.cz
                if (!settings.nody?.apiKey) {
                    return response.status(400).json({ error: 'Nody API not configured' });
                }

                const nodyService = new NodyService(settings.nody.apiUrl, settings.nody.apiKey);
                const nodyProducts = await nodyService.getCatalog();

                // Update or create products
                for (const nodyProduct of nodyProducts) {
                    const existingProduct = db.products.find(p => p.nodyId === nodyProduct.nodyId);
                    
                    if (existingProduct) {
                        // Update existing product
                        existingProduct.name = nodyProduct.name;
                        existingProduct.remoteStock = nodyProduct.remoteStock;
                        existingProduct.buyPrice = nodyProduct.buyPrice;
                        existingProduct.ean = nodyProduct.ean;
                        existingProduct.image = nodyProduct.image;
                        existingProduct.description = nodyProduct.description;
                    } else {
                        // Create new product
                        db.products.push({
                            id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            nodyId: nodyProduct.nodyId,
                            name: nodyProduct.name,
                            ean: nodyProduct.ean,
                            description: nodyProduct.description,
                            image: nodyProduct.image,
                            price: nodyProduct.buyPrice * 1.5, // Default 50% markup
                            buyPrice: nodyProduct.buyPrice,
                            vat: nodyProduct.vat || 21,
                            totalKeys: 0,
                            availableKeys: 0,
                            remoteStock: nodyProduct.remoteStock,
                            autoFulfill: true
                        });
                    }
                }

                await saveDb(db);
                return response.status(200).json({ 
                    success: true, 
                    message: `Synchronized ${nodyProducts.length} products from Nody`,
                    products: db.products 
                });
            }
            else if (action === 'update') {
                // Update product
                const { productId, updates } = request.body;
                const product = db.products.find(p => p.id === productId);
                
                if (!product) {
                    return response.status(404).json({ error: 'Product not found' });
                }

                Object.assign(product, updates);
                await saveDb(db);
                return response.status(200).json({ success: true, product });
            }
            else if (action === 'delete') {
                // Delete product
                const { productId } = request.body;
                db.products = db.products.filter(p => p.id !== productId);
                await saveDb(db);
                return response.status(200).json({ success: true, message: 'Product deleted' });
            }
            else if (action === 'buy_licenses') {
                // Bulk buy licenses from Nody
                const { productId, quantity } = request.body;
                const product = db.products.find(p => p.id === productId);
                
                if (!product) {
                    return response.status(404).json({ error: 'Product not found' });
                }

                if (!settings.nody?.apiKey) {
                    return response.status(400).json({ error: 'Nody API not configured' });
                }

                const nodyService = new NodyService(settings.nody.apiUrl, settings.nody.apiKey);
                const boughtKeys = [];

                for (let i = 0; i < quantity; i++) {
                    try {
                        const key = await nodyService.buyLicense(product.nodyId, `BULK-${Date.now()}`);
                        if (key) {
                            db.keys.push({
                                id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                                code: key,
                                productId: product.id,
                                isUsed: false,
                                isActive: true,
                                source: 'NODY',
                                createdAt: new Date().toISOString()
                            });
                            boughtKeys.push(key);
                        }
                    } catch (error) {
                        console.error('[PRODUCTS] Failed to buy license:', error);
                    }
                }

                // Update product key counts
                product.totalKeys += boughtKeys.length;
                product.availableKeys += boughtKeys.length;

                await saveDb(db);
                return response.status(200).json({ 
                    success: true, 
                    message: `Bought ${boughtKeys.length} licenses`,
                    keys: boughtKeys 
                });
            }
            else {
                // Create new product
                const newProduct = request.body;
                newProduct.id = Date.now().toString();
                newProduct.totalKeys = 0;
                newProduct.availableKeys = 0;
                db.products.push(newProduct);
                await saveDb(db);
                return response.status(200).json({ success: true, product: newProduct });
            }
        } catch (error) {
            console.error('[PRODUCTS ERROR]', error);
            return response.status(500).json({ error: error.message });
        }
    } else {
        // GET products
        const db = await loadDb();
        return response.status(200).json(db.products || []);
    }
};