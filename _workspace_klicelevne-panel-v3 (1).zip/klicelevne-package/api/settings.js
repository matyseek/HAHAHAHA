const { loadDb, saveDb } = require('./db');

module.exports = async function handler(request, response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    
    if (request.method === 'POST') {
        try {
            const db = await loadDb();
            const newSettings = request.body;
            
            // Merge settings but keep sensitive data if not provided
            const currentSettings = db.settings || {};
            db.settings = {
                ...currentSettings,
                ...newSettings,
                nody: {
                    ...currentSettings.nody,
                    ...newSettings.nody
                },
                smtp: {
                    ...currentSettings.smtp,
                    ...newSettings.smtp
                }
            };
            
            await saveDb(db);
            return response.status(200).json({ success: true, message: 'Nastavení uloženo', settings: db.settings });
        } catch (error) {
            console.error('[SETTINGS ERROR]', error);
            return response.status(500).json({ error: error.message });
        }
    } else {
        // GET settings - return settings without sensitive data
        const db = await loadDb();
        const settings = db.settings || {};
        
        // Mask sensitive data
        const safeSettings = {
            ...settings,
            nody: {
                ...settings.nody,
                apiKey: settings.nody?.apiKey ? '***HIDDEN***' : ''
            },
            smtp: {
                ...settings.smtp,
                pass: settings.smtp?.pass ? '***HIDDEN***' : ''
            }
        };
        
        return response.status(200).json(safeSettings);
    }
};