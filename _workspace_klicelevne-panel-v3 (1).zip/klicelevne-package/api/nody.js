
const axios = require('axios');

class NodyService {
    constructor(apiUrl, apiKey) {
        this.apiUrl = apiUrl || 'https://api.nody.cz/v1';
        this.apiKey = apiKey;
        
        console.log(`[NODY] Initializing service with API URL: ${this.apiUrl}`);
        console.log(`[NODY] API Key length: ${this.apiKey ? this.apiKey.length : 0}`);
        
        this.client = axios.create({
            baseURL: this.apiUrl,
            headers: {
                'Authorization': `Bearer ${this.apiKey}`,
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            timeout: 30000 // 30 second timeout
        });
    }

    /**
     * Stáhne seznam všech produktů z Nody.
     * Očekává, že API vrací pole objektů s EAN, cenou, obrázkem atd.
     */
    async getCatalog() {
        try {
            console.log('[NODY] Fetching product catalog...');
            const response = await this.client.get('/products');
            
            console.log(`[NODY] Got response status: ${response.status}`);
            console.log(`[NODY] Response data type: ${typeof response.data}`);
            
            // Mapování odpovědi Nody na náš formát
            const items = response.data.data || response.data; 

            if (!Array.isArray(items)) {
                console.error('[NODY] Response data is not an array:', response.data);
                throw new Error('Invalid response format from Nody API');
            }

            console.log(`[NODY] Processing ${items.length} products`);
            
            return items.map(item => ({
                nodyId: item.id,
                name: item.name,
                ean: item.ean || item.code || '',
                image: item.image_url || item.image || '',
                description: item.description || item.short_description || '',
                buyPrice: item.price_wholesale || item.price || 0,
                vat: item.vat_rate || item.vat || 21,
                remoteStock: item.stock_count || (item.in_stock ? 999 : 0),
                category: item.category || '',
                isActive: item.active !== false
            }));
        } catch (error) {
            console.error('[NODY API ERROR] Get Catalog:', error.message);
            if (error.response) {
                console.error('[NODY] Response status:', error.response.status);
                console.error('[NODY] Response data:', error.response.data);
            }
            throw error;
        }
    }

    /**
     * Získá detail jednoho produktu a jeho aktuální sklad
     */
    async getProductStock(nodyId) {
        try {
            console.log(`[NODY] Checking stock for product: ${nodyId}`);
            const response = await this.client.get(`/products/${nodyId}`);
            const item = response.data;
            const stock = item.stock_count || (item.in_stock ? 999 : 0);
            console.log(`[NODY] Stock for ${nodyId}: ${stock}`);
            return stock;
        } catch (error) {
            console.error(`[NODY] Error getting stock for ${nodyId}:`, error.message);
            return 0;
        }
    }

    /**
     * (Volitelné) Nákup licence přes API
     */
    async buyLicense(nodyId, orderReference) {
        try {
            console.log(`[NODY] Buying license for product: ${nodyId}, ref: ${orderReference}`);
            const response = await this.client.post('/orders', {
                product_id: nodyId,
                quantity: 1,
                reference: orderReference
            });
            
            console.log(`[NODY] Purchase response status: ${response.status}`);
            
            // Předpoklad: vrátí klíč
            const key = response.data.keys ? response.data.keys[0] : response.data.key || response.data.license_key;
            
            if (key) {
                console.log(`[NODY] Successfully purchased license: ${key}`);
            } else {
                console.warn('[NODY] No key in response:', response.data);
            }
            
            return key;
        } catch (error) {
            console.error('[NODY API ERROR] Buy License:', error.response?.data || error.message);
            if (error.response) {
                console.error('[NODY] Response status:', error.response.status);
                console.error('[NODY] Response data:', error.response.data);
            }
            return null;
        }
    }
}

module.exports = NodyService;
