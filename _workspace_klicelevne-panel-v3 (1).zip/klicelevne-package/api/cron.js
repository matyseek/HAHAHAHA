const nodemailer = require('nodemailer');
const { loadDb, saveDb } = require('./db');
const NodyService = require('./nody');
const emailService = require('./email');

module.exports = async function handler(request, response) {
    response.setHeader('Access-Control-Allow-Origin', '*');
    
    if (request.method === 'POST') {
        try {
            const action = request.body.action;
            const db = await loadDb();
            const settings = db.settings || {};

            // Initialize services
            let nodyService = null;
            if (settings.nody?.apiKey) {
                nodyService = new NodyService(settings.nody.apiUrl, settings.nody.apiKey);
            }

            if (settings.smtp?.host && settings.smtp?.user && settings.smtp?.pass) {
                await emailService.initTransporter(settings.smtp);
            }

            if (action === 'check_low_stock') {
                // Check for low stock and send alerts
                const lowStockProducts = db.products.filter(p => {
                    const threshold = p.lowStockThreshold || 5;
                    return p.availableKeys < threshold;
                });

                if (lowStockProducts.length > 0 && emailService.transporter) {
                    const adminEmail = settings.smtp?.user;
                    
                    let message = `
                        <h3>⚠️ Upozornění na nízký stav skladu</h3>
                        <p>Následující produkty mají nízký stav skladu:</p>
                        <ul>
                            ${lowStockProducts.map(p => `
                                <li>
                                    <strong>${p.name}</strong><br>
                                    Dostupné klíče: ${p.availableKeys}/${p.totalKeys}<br>
                                    Nody ID: ${p.nodyId}
                                </li>
                            `).join('')}
                        </ul>
                        <p>Doporučujeme doplnit sklad.</p>
                    `;

                    try {
                        await emailService.sendAdminNotification({
                            subject: 'Nízký stav skladu',
                            message,
                            adminEmail,
                            storeName: settings.storeName
                        });
                    } catch (error) {
                        console.error('[CRON] Failed to send low stock alert:', error);
                    }
                }

                return response.status(200).json({ 
                    success: true, 
                    message: `Checked ${lowStockProducts.length} low stock products`,
                    lowStockProducts 
                });
            }
            else if (action === 'auto_fulfill_orders') {
                // Automatically fulfill pending orders
                const pendingOrders = db.orders.filter(o => 
                    o.status === 'PAID' || o.status === 'PENDING'
                );

                const results = [];

                for (const order of pendingOrders) {
                    try {
                        let licenseKey = null;
                        for (const item of order.items) {
                            const key = db.keys.find(k => 
                                k.productId === item.nodyId && 
                                !k.isUsed && 
                                k.isActive
                            );
                            if (key) {
                                licenseKey = key;
                                key.isUsed = true;
                                key.usedDate = new Date().toISOString();
                                key.assignedToEmail = order.email;
                                key.orderNumber = order.orderNumber;
                                break;
                            }
                        }

                        if (!licenseKey && settings.nody?.autoPurchase && nodyService) {
                            for (const item of order.items) {
                                try {
                                    const boughtKey = await nodyService.buyLicense(item.nodyId, order.orderNumber);
                                    if (boughtKey) {
                                        licenseKey = {
                                            id: Date.now().toString(),
                                            code: boughtKey,
                                            productId: item.nodyId,
                                            isUsed: true,
                                            isActive: true,
                                            assignedToEmail: order.email,
                                            orderNumber: order.orderNumber,
                                            source: 'NODY',
                                            usedDate: new Date().toISOString()
                                        };
                                        db.keys.push(licenseKey);
                                        break;
                                    }
                                } catch (error) {
                                    console.error('[CRON] Failed to auto-buy license:', error);
                                }
                            }
                        }

                        if (licenseKey) {
                            if (emailService.transporter) {
                                try {
                                    await emailService.sendLicenseEmail({
                                        customerEmail: order.email,
                                        customerName: order.customerName,
                                        orderNumber: order.orderNumber,
                                        productName: order.items[0].productName,
                                        licenseKey: licenseKey.code,
                                        storeName: settings.storeName
                                    });
                                    order.status = 'SENT';
                                    order.licenseSent = true;
                                    order.licenseSentDate = new Date().toISOString();
                                    results.push({ orderId: order.id, success: true });
                                } catch (error) {
                                    order.status = 'EMAIL_FAILED';
                                    results.push({ orderId: order.id, success: false, error: 'Email failed' });
                                }
                            } else {
                                order.status = 'SENT';
                                results.push({ orderId: order.id, success: true });
                            }
                        } else {
                            results.push({ orderId: order.id, success: false, error: 'No key available' });
                        }
                    } catch (error) {
                        results.push({ orderId: order.id, success: false, error: error.message });
                    }
                }

                await saveDb(db);
                return response.status(200).json({ 
                    success: true, 
                    message: `Processed ${results.length} orders`,
                    results 
                });
            }
            else if (action === 'sync_nody_catalog') {
                if (!nodyService) {
                    return response.status(400).json({ error: 'Nody not configured' });
                }

                const nodyProducts = await nodyService.getCatalog();

                for (const nodyProduct of nodyProducts) {
                    const existingProduct = db.products.find(p => p.nodyId === nodyProduct.nodyId);
                    
                    if (existingProduct) {
                        existingProduct.remoteStock = nodyProduct.remoteStock;
                        existingProduct.buyPrice = nodyProduct.buyPrice;
                    } else {
                        db.products.push({
                            id: Date.now().toString() + Math.random().toString(36).substr(2, 5),
                            nodyId: nodyProduct.nodyId,
                            name: nodyProduct.name,
                            ean: nodyProduct.ean,
                            description: nodyProduct.description,
                            image: nodyProduct.image,
                            price: nodyProduct.buyPrice * 1.5,
                            buyPrice: nodyProduct.buyPrice,
                            vat: nodyProduct.vat || 21,
                            totalKeys: 0,
                            availableKeys: 0,
                            remoteStock: nodyProduct.remoteStock,
                            autoFulfill: true
                        });
                    }
                }

                await saveDb(db);
                return response.status(200).json({ 
                    success: true, 
                    message: `Synced ${nodyProducts.length} products` 
                });
            }
            else {
                // Legacy fulfillment for backward compatibility
                console.log('[CRON] Spouštím fulfillment...');
                let changes = false;
                let emailsSent = 0;

                const pendingOrders = (db.orders || []).filter(o => o.status === 'PAID');

                for (const order of pendingOrders) {
                    let orderKeys = [];
                    let allItemsCovered = true;

                    for (const item of order.items) {
                        let key = (db.keys || []).find(k => k.productId === item.nodyId && !k.isUsed && k.isActive);

                        if (!key && settings.nody && settings.nody.autoPurchase && nodyService && item.nodyId) {
                            try {
                                const remoteKey = "NODY-AUTO-" + Math.random().toString(36).substr(2,8).toUpperCase();
                                key = {
                                    id: Math.random().toString(36).substr(2,9),
                                    code: remoteKey,
                                    productId: item.nodyId,
                                    activationsMax: 1,
                                    activationsUsed: 0,
                                    isActive: true,
                                    isUsed: false,
                                    source: 'NODY'
                                };
                                db.keys.push(key);
                                changes = true;
                            } catch (err) {
                                console.error("[CRON] Auto-buy error:", err.message);
                            }
                        }

                        if (key && !key.isUsed) {
                            key.isUsed = true;
                            key.assignedToEmail = order.email;
                            key.orderNumber = order.orderNumber;
                            key.usedDate = new Date().toISOString();
                            orderKeys.push({ product: item.productName, code: key.code });
                            changes = true;
                        } else {
                            allItemsCovered = false;
                        }
                    }

                    if (allItemsCovered && orderKeys.length > 0) {
                        if (emailService.transporter) {
                            try {
                                const keyList = orderKeys.map(k => `${k.product}: ${k.code}`).join('\\n');
                                await emailService.sendLicenseEmail({
                                    customerEmail: order.email,
                                    customerName: order.customerName,
                                    orderNumber: order.orderNumber,
                                    productName: orderKeys[0].product,
                                    licenseKey: orderKeys[0].code,
                                    storeName: settings.storeName
                                });
                                emailsSent++;
                            } catch (mailErr) {
                                console.error("[CRON] Mail send error:", mailErr.message);
                            }
                        }
                        order.status = 'SENT';
                        changes = true;
                    }
                }

                if (changes) await saveDb(db);

                return response.status(200).json({ 
                    success: true, 
                    processed: pendingOrders.length, 
                    emailsSent 
                });
            }
        } catch (error) {
            console.error("[CRON] Fatal error:", error);
            return response.status(500).json({ error: error.message });
        }
    } else {
        return response.status(200).json({ 
            status: 'ready',
            availableActions: [
                'check_low_stock',
                'auto_fulfill_orders',
                'sync_nody_catalog'
            ]
        });
    }
};