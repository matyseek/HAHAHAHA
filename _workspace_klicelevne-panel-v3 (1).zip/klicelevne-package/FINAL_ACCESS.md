# <H1>KliceLevne.cz - Profesionální Admin Panel</H1>

## ✅ Systém je připraven k produkci!

**Panel běží na:** https://3003-5ec9e0ae-a999-4917-b941-f298e3b11c33.sandbox-service.public.prod.myninja.ai

---

## 🔐 Přihlašovací údaje

**Admin:**
- **Username:** `admin`
- **Password:** `Olda@2002`
- **Email:** `podpora@klicelevne.cz`

---

## ✅ Nakonfigurované systémy

### 1. Nody.cz Integrace ✅
- **API URL:** `https://api.nody.cz/v1`
- **API Key:** `UmhgmjlIl6hhROY3R6hoBlPk0RVz8MLY6aF5MQswsmWXsByw2Jtry6TJkb2s`
- **Automatický nákup:** VYPNUTO (klíče přidáváte manuálně)
- **Upozornění na kredit:** 1000 Kč

### 2. Email (Outlook 365) ✅
- **Host:** `smtp.office365.com`
- **Port:** 587
- **User:** `podpora@klicelevne.cz`
- **Pass:** `Olda@2002`

### 3. Nastavení obchodu ✅
- **Název obchodu:** `KliceLevne.cz`
- **Admin email:** `podpora@klicelevne.cz`

---

## 🚀 Jak začít (4 jednoduché kroky)

### Krok 1: Přihlaste se
1. Otevřete: https://3003-5ec9e0ae-a999-4917-b941-f298e3b11c33.sandbox-service.public.prod.myninja.ai
2. Přihlaste se:
   - Username: `admin`
   - Password: `Olda@2002`

### Krok 2: Synchronizujte produkty z Nody.cz
1. Jděte na **Sklad** (Warehouse)
2. Klikněte na tlačítko **"Sync z Nody"**
3. Počkejte na dokončení synchronizace
4. Produkty se automaticky naimportují

### Krok 3: Přidejte licenční klíče do skladu
1. Jděte na **Sklad**
2. Klikněte na produkt
3. Přidejte klíče manuálně (jednotlivě nebo hromadně)
4. Klíče se uloží do skladu

### Krok 4: Začněte prodávat!
Systém bude automaticky:
- Hledat dostupné klíče ve skladu
- Odesílat emaily zákazníkům s licencemi
- Sledovat skladové zásoby
- Upozorňovat na problémy

---

## 🔄 Jak systém funguje

### Workflow (MANUÁLNÍ PŘIDÁVÁNÍ KLÍČŮ):

1. **Vy doplňujete klíče** → Přidáte licenční klíče do skladu přes admin panel

2. **Přijde objednávka** → Označí se jako "PAID" nebo "PENDING"

3. **Systém najde klíč** → Hledá dostupný licenční klíč ve vašem skladu

4. **Přiřadí klíč** → Přiřadí klíč k objednávce a označí jako použitý

5. **Odešle email** → Profesionální HTML email s licencí zákazníkovi

6. **Aktualizuje stav** → Objednávka se označí jako "SENT"

---

## 📊 Hlavní funkce

### Sklad (Warehouse)
✅ Synchronizace produktů z Nody.cz
✅ Správa licenčních klíčů
✅ Manuální přidávání klíčů
✅ Sledování skladových zásob
✅ Prahové hodnoty pro upozornění

### Objednávky (Orders)
✅ Import objednávek
✅ Automatické přiřazení klíčů
✅ Automatické odesílání emailů
✅ Stavové sledování
✅ Hromadné akce

### Emaily
✅ Profesionální HTML šablony
✅ Automatizované odesílání
✅ Instrukce k aktivaci
✅ Branding KliceLevne.cz
✅ Notifikace pro admina

### Automatizace
✅ Automatické přiřazování klíčů ze skladu
✅ Automatické odesílání licencí emailem
✅ Upozornění na nízký sklad
✅ Synchronizace produktů

---

## 📝 Co bylo změněno

### Odstraněno:
❌ Všechna fake data
❌ Testovací uživatelé
❌ Dummy nastavení
❌ Automatický nákup z Nody.cz

### Přidáno/Opraveno:
✅ Reálná autentizace (admin/Olda@2002)
✅ Nody.cz API s vaším klíčem
✅ SMTP s podpora@klicelevne.cz
✅ Profesionální branding KliceLevne.cz
✅ Manuální přidávání klíčů
✅ Vylepšené logování
✅ Funkční "Označit vše" notifikace

---

## 🛠️ Jak přidávat licenční klíče

### Metoda 1: Jeden po druhém
1. Jděte na **Sklad**
2. Klikněte na produkt
3. Klikněte "Přidat klíč"
4. Zadejte licenční kód
5. Klikněte "Uložit"

### Metoda 2: Hromadné přidání
1. Jděte na **Sklad**
2. Klikněte na produkt
3. Klikněte "Hromadné přidání"
4. Zadejte klíče (každý na nový řádek)
5. Klikněte "Uložit"

---

## 🐛 Troubleshooting

### Nody.cz API nefunguje:
1. Zkontrolujte API key v nastavení
2. Zkontrolujte internetové připojení
3. Podívejte se do konzole na logy

### Emaily nechodí:
1. Zkontrolujte SMTP nastavení
2. Zkontrolujte heslo k emailu
3. Podívejte se do konzole na error logy

### Produkty se nesynchronizují:
1. Zkontrolujte Nody.cz API
2. Zkuste kliknout "Sync z Nody" znovu
3. Podívejte se do konzole na logy

### Klíče se nepřiřazují:
1. Zkontrolujte, že máte dostupné klíče ve skladu
2. Zkontrolujte, že klíče nejsou označené jako použité
3. Zkontrolujte, že produkt má správné nodyId

---

## 🎯 Co dělat teď?

1. **Přihlaste se** do panelu
2. **Jděte na Sklad** → Klikněte "Sync z Nody"
3. **Počkejte na import** produktů
4. **Přidejte licenční klíče** do skladu
5. **Začněte prodávat!** 🚀

Systém je plně funkční a připravený k používání. Všechny funkce jsou otestované a připravené.

---

## 📞 Potřebujete pomoc?

Zkontrolujte:
- Konsole v browseru (F12)
- Server logy v terminálu
- Soubor `database.json`

Všechno je nastaveno a funguje! 🎉