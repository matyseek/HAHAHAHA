
import { Order, OrderStatus, WarehouseProduct, LicenseKey, Payout, PanelUser, ActionLog } from './types';

export const MOCK_ORDERS: Order[] = [
  { 
    id: '1', 
    orderNumber: '2024001', 
    customerName: 'Jan Novák', 
    email: 'jan.novak@email.cz', 
    phone: '+420 777 123 456', 
    totalAmount: 1490, 
    status: OrderStatus.SENT, 
    date: '2024-05-15 10:30', 
    items: [{ productName: 'Windows 11 Pro', price: 1490, nodyId: 'n1' }] 
  },
  { 
    id: '2', 
    orderNumber: '2024002', 
    customerName: 'Petr Svoboda', 
    email: 'psvoboda@seznam.cz', 
    phone: '+420 608 999 888', 
    totalAmount: 1890, 
    status: OrderStatus.PAID, // Zaplaceno, čeká na vyřízení (třeba nákup z Nody)
    date: '2024-05-15 11:15', 
    items: [{ productName: 'Office 2021 Pro', price: 1890, nodyId: 'n2' }] 
  },
];

export const MOCK_KEYS: LicenseKey[] = [
  { id: 'k1', code: 'XXXX-YYYY-ZZZZ-0001', productId: 'p1', activationsUsed: 0, activationsMax: 1, isUsed: true, isActive: true, assignedToEmail: 'jan.novak@email.cz', orderNumber: '2024001', source: 'NODY', usedDate: '2024-05-15' },
];

export const MOCK_PRODUCTS: WarehouseProduct[] = [
  { 
    id: 'p1', 
    nodyId: 'n1',
    name: 'Windows 11 Pro', 
    ean: '885370920925',
    description: 'Elektronická licence ESD',
    image: 'https://upload.wikimedia.org/wikipedia/commons/e/e6/Windows_11_logo.svg',
    price: 1490,
    buyPrice: 850, // Cena na Nody
    totalKeys: 0, 
    availableKeys: 0,
    remoteStock: 999,
    autoFulfill: true // Automaticky koupit z Nody
  },
  { 
    id: 'p2', 
    nodyId: 'n2',
    name: 'Office 2021 Pro', 
    ean: '889842860434',
    description: 'Trvalá licence Office',
    image: 'https://upload.wikimedia.org/wikipedia/commons/5/5f/Microsoft_Office_logo_%282019%E2%80%93present%29.svg',
    price: 1890,
    buyPrice: 1200,
    totalKeys: 0, 
    availableKeys: 0,
    remoteStock: 50,
    autoFulfill: false // Manuální schválení
  }
];

export const MOCK_PAYOUTS: Payout[] = [
  { id: 'p1', date: '2024-05-15', description: 'Dobití kreditu Nody.cz', amount: -10000, type: 'EXPENSE' },
  { id: 'p2', date: '2024-05-15', description: 'Příjem z objednávek', amount: 3380, type: 'INCOME' },
];

export const MOCK_PANEL_USERS: PanelUser[] = [
  { id: 'u1', username: 'admin', role: 'ADMIN', email: 'admin@digitalstore.cz' },
];

export const MOCK_LOGS: ActionLog[] = [];
