# Změny pro funkční build

Projekt v repu je ve skutečnosti Vite (má `vite.config.ts` a root `index.html`), ale byl nastavený jako CRA (`react-scripts`).

## Co je změněno
- `package.json`: build/dev skripty přepnuty na Vite, přidány Vite devDependencies.

## Jak buildnout u tebe
1) Smaž staré závislosti:

```bash
rm -rf node_modules package-lock.json
```

2) Nainstaluj:

```bash
npm install
```

3) Build:

```bash
npm run build
```

4) Dev:

```bash
npm run dev
```
