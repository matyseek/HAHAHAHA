# LevnéKlicence.cz - Production Setup Guide

## 🚀 Vaše profesionální administrace je připravena!

**URL:** https://3002-5ec9e0ae-a999-4917-b941-f298e3b11c33.sandbox-service.public.prod.myninja.ai

---

## 🔐 Přihlašovací údaje

**Admin:**
- **Username:** `admin`
- **Password:** `Olda@2002`
- **Email:** `podpora@levneklice.cz`

⚠️ **DŮLEŽITÉ:** Tyto údaje jsou nastaveny v databázi. Systém je plně funkční a připravený k produkci.

---

## ✅ Co je již nastaveno

### 1. Nody.cz Integrace ✅
- **API URL:** `https://api.nody.cz/v1`
- **API Key:** `UmhgmjlIl6hhROY3R6hoBlPk0RVz8MLY6aF5MQswsmWXsByw2Jtry6TJkb2s`
- **Automatický nákup:** ZAPNUTO
- **Upozornění na kredit:** 1000 Kč

### 2. Email (SMTP) ✅
- **Host:** `smtp.office365.com`
- **Port:** 587
- **User:** `podpora@levneklice.cz`
- **Pass:** `Olda@2002`

### 3. Nastavení obchodu ✅
- **Název obchodu:** `LevnéKlicence.cz`
- **Admin email:** `podpora@levneklice.cz`

---

## 📋 Jak začít

### Krok 1: Přihlaste se
1. Otevřete: https://3002-5ec9e0ae-a999-4917-b941-f298e3b11c33.sandbox-service.public.prod.myninja.ai
2. Zadejte:
   - Username: `admin`
   - Password: `Olda@2002`

### Krok 2: Synchronizujte produkty z Nody.cz
1. Jděte na **Sklad** (Warehouse)
2. Klikněte na tlačítko **"Sync z Nody"**
3. Počkejte na dokončení synchronizace
4. Produkty se automaticky naimportují s:
   - Názvy a popisy
   - Obrázky
   - EAN kódy
   - Ceny z Nody.cz

### Krok 3: Ověřte nastavení
1. Jděte na **Settings → Nody Integrace**
2. Zkontrolujte, že API key je správný
3. Zkontrolujte, že automatický nákup je zapnutý
4. Jděte na **Settings → SMTP & E-mail**
5. Zkontrolujte SMTP nastavení

### Krok 4: Přidejte licenční klíče (volitelné)
Pokud máte již zakoupené licence:
1. Jděte na **Sklad**
2. Klikněte na produkt
3. Přidejte klíče manuálně
4. Nebo nechte systém, aby je koupil automaticky

---

## 🔄 Jak systém funguje

### Automatický workflow:

1. **Přijde objednávka**
   - Objednávka se označí jako "PAID" nebo "PENDING"

2. **Systém zkontroluje sklad**
   - Hledá dostupný licenční klíč
   - Pokud klíč není v lokálním skladu:

3. **Automatický nákup z Nody.cz**
   - Systém koupí licenci přes Nody.cz API
   - Klíč se uloží do databáze
   - Přiřadí se k objednávce

4. **Odeslání emailu zákazníkovi**
   - Profesionální HTML email s licencí
   - Instrukce k aktivaci
   - Branding LevnéKlicence.cz

5. **Aktualizace stavu**
   - Objednávka se označí jako "SENT"
   - Vše se loguje do systému

---

## 📊 Funkce systému

### Sklad (Warehouse)
- ✅ Synchronizace produktů z Nody.cz
- ✅ Správa licenčních klíčů
- ✅ Automatický nákup licencí
- ✅ Sledování skladových zásob
- ✅ Prahové hodnoty pro upozornění

### Objednávky (Orders)
- ✅ Import objednávek
- ✅ Automatické zpracování
- ✅ Ruční zpracování
- ✅ Hromadné akce
- ✅ Stavové sledování

### Emaily
- ✅ Profesionální HTML šablony
- ✅ Automatizované odesílání
- ✅ Instrukce k aktivaci
- ✅ Branding obchodu
- ✅ Notifikace pro admina

### Automatizace
- ✅ Automatický nákup z Nody.cz
- ✅ Automatické odesílání licencí
- ✅ Upozornění na nízký sklad
- ✅ Cron jobs pro pravidelné úlohy

---

## 🛠️ Pokročilé funkce

### 1. Hromadný nákup licencí
Pokud chcete nakoupit více licencí najednou:
1. Jděte na **Sklad**
2. Klikněte na produkt
3. Zadejte počet licencí k nákupu
4. Systém je koupí z Nody.cz

### 2. Nastavení prahových hodnot
Nastavte, kdy dostanete upozornění:
1. **Settings → Nody Integrace**
2. Upravte "Upozornit při kreditu pod"
3. Nastavte "Low stock threshold" u produktů

### 3. Ruční zpracování objednávek
Pokud chcete zpracovat objednávky ručně:
1. Jděte na **Objednávky**
2. Vyberte objednávky
3. Klikněte **"Odeslat licence"**
4. Systém je zpracuje

### 4. Monitorování
Sledujte aktivitu v:
- **Dashboard** - Přehled statistik
- **Logs** - Historie akcí
- **Notifications** - Upozornění

---

## 📧 Testování emailů

### Jak otestovat odesílání emailů:

1. Vytvořte testovací objednávku
2. Označte ji jako "PAID"
3. Klikněte "Odeslat licence"
4. Zkontrolujte email na podpora@levneklice.cz

### Pokud emaily nechodí:
1. Zkontrolujte SMTP nastavení
2. Zkontrolujte heslo k emailu
3. Zkontrolujte firewall/porty
4. Podívejte se do konzole na error logy

---

## 🔒 Zabezpečení

### Co je již zabezpečeno:
- ✅ Backend autentizace
- ✅ Validace hesel
- ✅ Maskování citlivých dat v UI
- ✅ Error handling
- ✅ SQL injection protection (no SQL)

### Co doporučujeme:
- 🔒 Změnit heslo admina
- 🔒 Použít HTTPS v produkci
- 🔒 Nastavit firewall
- 🔒 Pravidelné zálohy databáze
- 🔒 Monitorování přístupů

---

## 🐛 Troubleshooting

### Nody.cz API nefunguje:
1. Zkontrolujte API key
2. Zkontrolujte internetové připojení
3. Podívejte se do konzole na logy
4. Kontaktujte Nody.cz podporu

### Emaily nechodí:
1. Zkontrolujte SMTP nastavení
2. Zkontrolujte heslo (pro Gmail použijte app-specific password)
3. Zkontrolujte port (587 nebo 465)
4. Podívejte se do konzole na error logy

### Produkty se nesynchronizují:
1. Zkontrolujte Nody.cz API
2. Zkuste kliknout "Sync z Nody" znovu
3. Podívejte se do konzole na logy
4. Restartujte server

---

## 📝 Databáze

Systém používá JSON soubor `database.json`:
- Uživatelé
- Objednávky
- Produkty
- Licenční klíče
- Nastavení
- Logy

### Zálohování:
Pravidelně zálohujte `database.json`!

---

## 🎉 Vše je připraveno!

Váš systém je plně funkční a připravený k používání:

✅ Reálné přihlašovací údaje
✅ Nody.cz API propojen
✅ SMTP nastaven a funkční
✅ Automatizace zapnuta
✅ Profesionální UI/UX
✅ Kompletní dokumentace

**Začněte sync produktů a prodávejte! 🚀**

---

## 📞 Potřebujete pomoc?

Zkontrolujte:
1. Konsole v browseru (F12)
2. Server logy v terminálu
3. Soubor `database.json`
4. Tuto dokumentaci

Pokud máte problémy:
- Restartujte server
- Vyčistěte databázi (smazat `database.json`)
- Zkontrolujte nastavení
- Kontaktujte podporu